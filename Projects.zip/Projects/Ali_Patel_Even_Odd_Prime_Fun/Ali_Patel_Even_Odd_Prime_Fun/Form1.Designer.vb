﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbllow = New System.Windows.Forms.Label()
        Me.lblHigh = New System.Windows.Forms.Label()
        Me.txthigh = New System.Windows.Forms.TextBox()
        Me.txtlow = New System.Windows.Forms.TextBox()
        Me.lstOdd = New System.Windows.Forms.ListBox()
        Me.lstEven = New System.Windows.Forms.ListBox()
        Me.lstPrime = New System.Windows.Forms.ListBox()
        Me.btnList = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbllow
        '
        Me.lbllow.AutoSize = True
        Me.lbllow.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllow.Location = New System.Drawing.Point(12, 19)
        Me.lbllow.Name = "lbllow"
        Me.lbllow.Size = New System.Drawing.Size(54, 25)
        Me.lbllow.TabIndex = 0
        Me.lbllow.Text = "Low"
        '
        'lblHigh
        '
        Me.lblHigh.AutoSize = True
        Me.lblHigh.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHigh.Location = New System.Drawing.Point(12, 53)
        Me.lblHigh.Name = "lblHigh"
        Me.lblHigh.Size = New System.Drawing.Size(60, 25)
        Me.lblHigh.TabIndex = 1
        Me.lblHigh.Text = "High"
        '
        'txthigh
        '
        Me.txthigh.Location = New System.Drawing.Point(172, 58)
        Me.txthigh.Name = "txthigh"
        Me.txthigh.Size = New System.Drawing.Size(100, 20)
        Me.txthigh.TabIndex = 2
        '
        'txtlow
        '
        Me.txtlow.Location = New System.Drawing.Point(172, 24)
        Me.txtlow.Name = "txtlow"
        Me.txtlow.Size = New System.Drawing.Size(100, 20)
        Me.txtlow.TabIndex = 3
        '
        'lstOdd
        '
        Me.lstOdd.FormattingEnabled = True
        Me.lstOdd.Location = New System.Drawing.Point(17, 155)
        Me.lstOdd.Name = "lstOdd"
        Me.lstOdd.Size = New System.Drawing.Size(79, 95)
        Me.lstOdd.TabIndex = 4
        '
        'lstEven
        '
        Me.lstEven.FormattingEnabled = True
        Me.lstEven.Location = New System.Drawing.Point(102, 155)
        Me.lstEven.Name = "lstEven"
        Me.lstEven.Size = New System.Drawing.Size(85, 95)
        Me.lstEven.TabIndex = 5
        '
        'lstPrime
        '
        Me.lstPrime.FormattingEnabled = True
        Me.lstPrime.Location = New System.Drawing.Point(193, 155)
        Me.lstPrime.Name = "lstPrime"
        Me.lstPrime.Size = New System.Drawing.Size(79, 95)
        Me.lstPrime.TabIndex = 6
        '
        'btnList
        '
        Me.btnList.Location = New System.Drawing.Point(102, 103)
        Me.btnList.Name = "btnList"
        Me.btnList.Size = New System.Drawing.Size(75, 23)
        Me.btnList.TabIndex = 7
        Me.btnList.Text = "LIST THEM"
        Me.btnList.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.btnList)
        Me.Controls.Add(Me.lstPrime)
        Me.Controls.Add(Me.lstEven)
        Me.Controls.Add(Me.lstOdd)
        Me.Controls.Add(Me.txtlow)
        Me.Controls.Add(Me.txthigh)
        Me.Controls.Add(Me.lblHigh)
        Me.Controls.Add(Me.lbllow)
        Me.Name = "Form1"
        Me.Text = "EvenOddPrimeFun"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbllow As Label
    Friend WithEvents lblHigh As Label
    Friend WithEvents txthigh As TextBox
    Friend WithEvents txtlow As TextBox
    Friend WithEvents lstOdd As ListBox
    Friend WithEvents lstEven As ListBox
    Friend WithEvents lstPrime As ListBox
    Friend WithEvents btnList As Button
End Class
