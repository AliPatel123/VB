﻿Public Class Form1
    Private Sub btnList_Click(sender As Object, e As EventArgs) Handles btnList.Click
        Dim intlow As Integer = txtlow.Text 'Declaring the low as an integer variable
        Dim inthigh As Integer = txthigh.Text 'Declaring the high as an integer variable
        Dim count As Integer 'Declaring the count as an integer variable
        Dim prime As Integer 'Declaring the prime as an integer variable
        Dim primecounter As Integer 'Declaring a counter for prime numbers as an integer variable
        For count = intlow To inthigh 'Setting the boundaries of intlow and inthigh
            If count Mod 2 = 1 Then 'Checking if odd
                lstOdd.Items.Add(count) 'Displaying if odd
            ElseIf count Mod 2 = 0 Then 'Checking if even
                lstEven.Items.Add(count) 'Displaying if even
            End If
        Next
    End Sub
End Class
