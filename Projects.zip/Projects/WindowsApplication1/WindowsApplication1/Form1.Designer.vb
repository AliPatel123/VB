﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PicDasani = New System.Windows.Forms.PictureBox()
        Me.PicCrush = New System.Windows.Forms.PictureBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PicPepsi = New System.Windows.Forms.PictureBox()
        Me.PicMountainDew = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblAnswer = New System.Windows.Forms.Label()
        CType(Me.PicDasani, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicCrush, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPepsi, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicMountainDew, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PicDasani
        '
        Me.PicDasani.Image = Global.WindowsApplication1.My.Resources.Resources.dasani
        Me.PicDasani.Location = New System.Drawing.Point(152, 53)
        Me.PicDasani.Name = "PicDasani"
        Me.PicDasani.Size = New System.Drawing.Size(106, 92)
        Me.PicDasani.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicDasani.TabIndex = 1
        Me.PicDasani.TabStop = False
        '
        'PicCrush
        '
        Me.PicCrush.Image = Global.WindowsApplication1.My.Resources.Resources.crush
        Me.PicCrush.Location = New System.Drawing.Point(12, 53)
        Me.PicCrush.Name = "PicCrush"
        Me.PicCrush.Size = New System.Drawing.Size(122, 91)
        Me.PicCrush.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicCrush.TabIndex = 0
        Me.PicCrush.TabStop = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(202, 15)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 2
        '
        'PicPepsi
        '
        Me.PicPepsi.Image = Global.WindowsApplication1.My.Resources.Resources.pepsi
        Me.PicPepsi.Location = New System.Drawing.Point(150, 159)
        Me.PicPepsi.Name = "PicPepsi"
        Me.PicPepsi.Size = New System.Drawing.Size(122, 91)
        Me.PicPepsi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPepsi.TabIndex = 3
        Me.PicPepsi.TabStop = False
        '
        'PicMountainDew
        '
        Me.PicMountainDew.Image = Global.WindowsApplication1.My.Resources.Resources.mountain_dew
        Me.PicMountainDew.Location = New System.Drawing.Point(12, 159)
        Me.PicMountainDew.Name = "PicMountainDew"
        Me.PicMountainDew.Size = New System.Drawing.Size(122, 91)
        Me.PicMountainDew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicMountainDew.TabIndex = 4
        Me.PicMountainDew.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label1.Location = New System.Drawing.Point(12, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(156, 19)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Put in your choice:"
        '
        'LblAnswer
        '
        Me.LblAnswer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblAnswer.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblAnswer.Location = New System.Drawing.Point(12, 268)
        Me.LblAnswer.Name = "LblAnswer"
        Me.LblAnswer.Size = New System.Drawing.Size(295, 25)
        Me.LblAnswer.TabIndex = 6
        Me.LblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(314, 311)
        Me.Controls.Add(Me.LblAnswer)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PicMountainDew)
        Me.Controls.Add(Me.PicPepsi)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.PicDasani)
        Me.Controls.Add(Me.PicCrush)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Ex01 Pop Machine"
        CType(Me.PicDasani, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicCrush, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPepsi, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicMountainDew, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PicCrush As PictureBox
    Friend WithEvents PicDasani As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents PicPepsi As PictureBox
    Friend WithEvents PicMountainDew As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents LblAnswer As Label
End Class
