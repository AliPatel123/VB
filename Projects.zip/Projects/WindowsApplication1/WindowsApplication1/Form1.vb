﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub PicCrush_Click(sender As Object, e As EventArgs) Handles PicCrush.Click
        LblAnswer.Text = "Enjoy your crush!"
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PicPepsi.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Form1_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LblAnswer_Click(sender As Object, e As EventArgs) Handles LblAnswer.Click

    End Sub
End Class
