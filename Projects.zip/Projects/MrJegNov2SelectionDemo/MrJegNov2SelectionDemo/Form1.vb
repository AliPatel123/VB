﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim isHungry As Boolean
        'isHungry = False
        ' If isHungry = True Then
        'lblDisplay.Text = "Call Pizza Hut"
        'Else
        'lblDisplay.Text = "Do Mr J's Assignment"

        'End If
        'Rational Operators
        Dim intAge As Integer
        intAge = 23
        'Check whether the person is old enough to vote
        Dim IsUsCitizen As Boolean = True
        IsUsCitizen = txtCitizen.Text
        If intAge >= 18 And IsUsCitizen Then
            lblDisplay.Text = "You are eligible to vote"
        Else
            lblDisplay.Text = "You are not eligible to vote"
        End If
    End Sub
End Class
