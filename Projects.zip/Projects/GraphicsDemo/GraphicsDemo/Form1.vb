﻿Public Class Form1
    Private Sub Form1_Paint(ByVal sender As Object, ByVal e _
        As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint

        ' Draw a solid black line 25 pixels from the top of the form.
        Dim intcount As Integer
        For intcount = 1 To 100
            e.Graphics.DrawEllipse(Pens.Red, 200 + intcount, 200, 50, 50)
            System.Threading.Thread.Sleep(50)
            e.Graphics.Clear(Color.White)


        Next
        e.Graphics.DrawLine(Pens.Red, 0, 0, 100, 100)




    End Sub

End Class
