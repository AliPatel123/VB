﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblDisplay.Click
        lblDisplay.Text = "Hello"
        With lblDisplay

            'With Statement Allow us to change the
            ' properties of a Contol
            lblDisplay.ForeColor = Color.Red
            lblDisplay.TextAlign = ContentAlignment.BottomRight
            'lblDisplay.Location = New Point (390, 390)
        End With
    End Sub
End Class
