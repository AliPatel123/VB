﻿Module Module1

    Sub Main()
        Dim strName As String = Console.ReadLine
        Dim intVowelCount As Integer = 0
        Dim vowel As String = "IOSHZXN"
        Dim i As Integer = 0
        For i = 0 To strName.Length - 1
            If (vowel.IndexOf(strName(i)) >= 0) Then
                intVowelCount += 1
            End If
        Next
        If (intVowelCount = strName.Length) Then
            Console.WriteLine("YES")
        Else
            Console.WriteLine("NO")
        End If
        Console.ReadLine()
    End Sub
End Module
