﻿Public Class Form1
    Private Sub lblDisplay_Click(sender As Object, e As EventArgs) Handles lblDisplay.Click
        'Declaring an Integer Variable In VB
        Dim intnum1 As Integer 'intnum1 is declared as an Integer Variable
        intnum1 = 5 'intnum1 is assigned to a value of 5
        'Addition in VB
        intnum1 = intnum1 + 5
        lblDisplay.Text = intnum1
        'Subtraction
        intnum1 = intnum1 - 20
        lblDisplay.Text = intnum1
        'Multipication
        intnum1 = intnum1 * 100
        lblDisplay.Text = intnum1
        'Division
        intnum1 = 10
        intnum1 = intnum1 / 3
        lblDisplay.Text = intnum1
        'In VB when you divide an integer by an integer
        'the nd result is always an integer
        intnum1 = 75
        intnum1 = intnum1 Mod 60
        lblDisplay.Text = intnum1
    End Sub
End Class
