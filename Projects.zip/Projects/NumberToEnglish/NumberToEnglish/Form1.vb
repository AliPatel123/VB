﻿Public Class Form1
    Dim strWord As String = ""
    Dim intNum As Integer
    Dim intNum2 As Integer
    Dim intNum3 As Integer
    Dim str1 As String
    Dim str2 As String
    Dim str3 As String
    Dim str4 As String
    Dim str5 As String
    Dim str6 As String
    Dim str7 As String
    Dim str8 As String
    Dim str9 As String
    Dim str10 As String
    Dim str11 As String
    Dim str12 As String
    Dim str13 As String
    Dim str14 As String
    Dim str15 As String
    Dim str16 As String
    Dim str17 As String
    Dim str18 As String
    Dim str19 As String
    Dim str20 As String
    Dim str30 As String
    Dim str40 As String
    Dim str50 As String
    Dim str60 As String
    Dim str70 As String
    Dim str80 As String
    Dim str90 As String
    Dim str100 As String
    Dim str1000 As String
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        strWord = ""
        intNum = txtNumber.Text \ 100
        If intNum = 10 Then
            strWord = "One Thousand"
        ElseIf intNum = 9 Then
            strWord = "Nine Hundred"
        ElseIf intNum = 8 Then
            strWord = "Eight Hundred"
        ElseIf intNum = 7 Then
            strWord = "Seven Hundred"
        ElseIf intNum = 6 Then
            strWord = "Six Hundred"
        ElseIf intNum = 5 Then
            strWord = "Five Hundred"
        ElseIf intNum = 4 Then
            strWord = "Four Hundred"
        ElseIf intNum = 3 Then
            strWord = "Three Hundred"
        ElseIf intNum = 2 Then
            strWord = "Two Hundred"
        ElseIf intNum = 1 Then
            strWord = "One Hundred"
        ElseIf intNum = 0 Then
            strWord = ""
        End If
        intNum2 = txtNumber.Text Mod 100
        If intNum2 \ 10 = 9 Then
            strWord = strWord & " Ninety "
        ElseIf intNum2 \ 10 = 8 Then
            strWord = strWord & " Eighty "
        ElseIf intNum2 \ 10 = 7 Then
            strWord = strWord & " Seventy "
        ElseIf intNum2 \ 10 = 6 Then
            strWord = strWord & " Sixty "
        ElseIf intNum2 \ 10 = 5 Then
            strWord = strWord & " Fifty "
        ElseIf intNum2 \ 10 = 4 Then
            strWord = strWord & " Forty "
        ElseIf intNum2 \ 10 = 3 Then
            strWord = strWord & " Thirty "
        ElseIf intNum2 \ 10 = 2 Then
            strWord = strWord & " Twenty "
        ElseIf intNum2 = 19 Then
            strWord = strWord & " Nineteen "
        ElseIf intNum2 = 18 Then
            strWord = strWord & " Eighteen "
        ElseIf intNum2 = 17 Then
            strWord = strWord & " Seventeen "
        ElseIf intNum2 = 16 Then
            strWord = strWord & " Sixteen "
        ElseIf intNum2 = 15 Then
            strWord = strWord & " Fifteen "
        ElseIf intNum2 = 14 Then
            strWord = strWord & " Fourteen "
        ElseIf intNum2 = 13 Then
            strWord = strWord & " Thirteen "
        ElseIf intNum2 = 12 Then
            strWord = strWord & " Twelve "
        ElseIf intNum2 = 11 Then
            strWord = strWord & " Eleven "
        ElseIf intNum2 = 10 Then
            strWord = strWord & " Ten "
        End If
        intNum3 = (txtNumber.Text Mod 100) Mod 10
        If intNum3 = 9 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Nine"
        ElseIf intNum3 = 8 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Eight"
        ElseIf intNum3 = 7 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Seven"
        ElseIf intNum3 = 6 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Six"
        ElseIf intNum3 = 5 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Five"
        ElseIf intNum3 = 4 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Four"
        ElseIf intNum3 = 3 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Three"
        ElseIf intNum3 = 2 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "Two"
        ElseIf intNum3 = 1 And intNum2 <> 11 And intNum2 <> 12 And intNum2 <> 13 And intNum2 <> 14 And intNum2 <> 15 And intNum2 <> 16 And intNum2 <> 17 And intNum2 <> 18 And intNum2 <> 19 Then
            strWord = strWord & "One"

        End If

        txtWords.Text = strWord

    End Sub
End Class
