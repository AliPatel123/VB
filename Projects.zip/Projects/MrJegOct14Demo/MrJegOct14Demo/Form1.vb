﻿Public Class Form1
    Private Sub btnDisplay1_Click(sender As Object, e As EventArgs) Handles btnDisplay1.Click
        Dim Name As String ' Name is declared as a String Variable
        Name = txtName.Text 'Get The Name From the user inside the textbox
        lblDisplay1.Text = "Welcome " & Name & " To VB"

    End Sub
End Class
