﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class txtName
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDisplay1 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblDisplay2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btnDisplay1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblDisplay1
        '
        Me.lblDisplay1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisplay1.ForeColor = System.Drawing.Color.Red
        Me.lblDisplay1.Location = New System.Drawing.Point(12, 44)
        Me.lblDisplay1.Name = "lblDisplay1"
        Me.lblDisplay1.Size = New System.Drawing.Size(113, 33)
        Me.lblDisplay1.TabIndex = 0
        Me.lblDisplay1.Text = "Welcome"
        '
        'lblDisplay2
        '
        Me.lblDisplay2.AutoSize = True
        Me.lblDisplay2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisplay2.Location = New System.Drawing.Point(13, 122)
        Me.lblDisplay2.Name = "lblDisplay2"
        Me.lblDisplay2.Size = New System.Drawing.Size(171, 24)
        Me.lblDisplay2.TabIndex = 1
        Me.lblDisplay2.Text = "Enter Your Name"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(224, 127)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 2
        '
        'btnDisplay1
        '
        Me.btnDisplay1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplay1.Location = New System.Drawing.Point(17, 181)
        Me.btnDisplay1.Name = "btnDisplay1"
        Me.btnDisplay1.Size = New System.Drawing.Size(108, 39)
        Me.btnDisplay1.TabIndex = 3
        Me.btnDisplay1.Text = "Display"
        Me.btnDisplay1.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(822, 360)
        Me.Controls.Add(Me.btnDisplay1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.lblDisplay2)
        Me.Controls.Add(Me.lblDisplay1)
        Me.Name = "txtName"
        Me.Text = "MrJegOct14Demo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDisplay1 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lblDisplay2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents btnDisplay1 As Button
End Class
