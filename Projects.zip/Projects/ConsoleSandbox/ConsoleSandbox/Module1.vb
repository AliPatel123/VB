﻿Module Module1
    Sub Main()
        Dim eenie, meenie As Integer
        For eenie = 10 To 3 Step -2
            meenie = 2
            For meenie = 1 To 10 Step 5
                meenie += eenie
                Console.WriteLine(meenie)
            Next meenie
        Next
        Console.ReadLine()
    End Sub
End Module
