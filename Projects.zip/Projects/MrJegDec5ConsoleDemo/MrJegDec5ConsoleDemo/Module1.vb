﻿Module Module1

    Sub Main()
        Console.WriteLine("Hello World!")
        Dim intnum As Integer
        intnum = Console.ReadLine
        Console.WriteLine("intnum = " & intnum)
        Dim int1 As Integer = 20
        Dim int2 As Integer = 30
        Dim int3 As Integer = 50
        Console.WriteLine("The sum of " & int1 & " and " & int2 & " is " & int3)
        Console.ReadLine()
    End Sub

End Module
