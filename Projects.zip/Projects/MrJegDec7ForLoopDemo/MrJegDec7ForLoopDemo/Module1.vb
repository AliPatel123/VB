﻿Module Module1

    Sub Main()
        'Dim intcount As Integer
        'Do While True
        'If intcount = 1 Then
        'Console.WriteLine("Mr Jeg")
        'intcount = 0
        'ElseIf intcount = 0 Then
        'Console.WriteLine("VB Demo")
        'intcount = 1
        'End If

        'Loop
        'For intcount = 1 To 5
        'Console.WriteLine(intcount * 1 & vbTab & intcount * 2 & vbTab & intcount * 3 & vbTab & intcount * 4 & vbTab & intcount * 5 & vbTab)
        'Next
        'Console.ReadLine()

        Dim intmarks, inttotal, intcount As Integer
        'For intcount = 1 To 10
        'intmarks = Console.ReadLine
        'inttotal = inttotal + intmarks
        'Next
        'If inttotal / 10 = 666 Then
        'Console.Write("LOOMINARTY CONFIRMED")
        'Console.ReadLine()
        'Else
        'Console.Write("Average : " & inttotal / 10)
        'Console.ReadLine()
        'End If
        Dim Odd As Integer
        Dim Even As Integer
        For intcount = 1 To 10
            intmarks = Console.ReadLine
            inttotal += intmarks
            If intmarks Mod 2 = 1 Then
                Odd += 1
            Else Even += 1
            End If
        Next
        Console.WriteLine(Odd)
        Console.WriteLine(Even)
        Console.ReadLine()
    End Sub

End Module
