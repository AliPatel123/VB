﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblEnterTime = New System.Windows.Forms.Label()
        Me.lblOttawa = New System.Windows.Forms.Label()
        Me.lblVictoria = New System.Windows.Forms.Label()
        Me.lblEdmonton = New System.Windows.Forms.Label()
        Me.lblWinnipeg = New System.Windows.Forms.Label()
        Me.lblToronto = New System.Windows.Forms.Label()
        Me.lblHalifax = New System.Windows.Forms.Label()
        Me.txtEnterTime = New System.Windows.Forms.TextBox()
        Me.txtOttawa = New System.Windows.Forms.TextBox()
        Me.txtVictoria = New System.Windows.Forms.TextBox()
        Me.txtEdmonton = New System.Windows.Forms.TextBox()
        Me.txtWinnipeg = New System.Windows.Forms.TextBox()
        Me.txtToronto = New System.Windows.Forms.TextBox()
        Me.txtHalifax = New System.Windows.Forms.TextBox()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblEnterTime
        '
        Me.lblEnterTime.AutoSize = True
        Me.lblEnterTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnterTime.Location = New System.Drawing.Point(26, 63)
        Me.lblEnterTime.Name = "lblEnterTime"
        Me.lblEnterTime.Size = New System.Drawing.Size(272, 25)
        Me.lblEnterTime.TabIndex = 0
        Me.lblEnterTime.Text = "Enter the time in Ottawa:"
        '
        'lblOttawa
        '
        Me.lblOttawa.AutoSize = True
        Me.lblOttawa.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOttawa.Location = New System.Drawing.Point(26, 124)
        Me.lblOttawa.Name = "lblOttawa"
        Me.lblOttawa.Size = New System.Drawing.Size(85, 25)
        Me.lblOttawa.TabIndex = 1
        Me.lblOttawa.Text = "Ottawa"
        '
        'lblVictoria
        '
        Me.lblVictoria.AutoSize = True
        Me.lblVictoria.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVictoria.Location = New System.Drawing.Point(26, 181)
        Me.lblVictoria.Name = "lblVictoria"
        Me.lblVictoria.Size = New System.Drawing.Size(92, 25)
        Me.lblVictoria.TabIndex = 2
        Me.lblVictoria.Text = "Victoria"
        '
        'lblEdmonton
        '
        Me.lblEdmonton.AutoSize = True
        Me.lblEdmonton.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEdmonton.Location = New System.Drawing.Point(26, 241)
        Me.lblEdmonton.Name = "lblEdmonton"
        Me.lblEdmonton.Size = New System.Drawing.Size(117, 25)
        Me.lblEdmonton.TabIndex = 3
        Me.lblEdmonton.Text = "Edmonton"
        '
        'lblWinnipeg
        '
        Me.lblWinnipeg.AutoSize = True
        Me.lblWinnipeg.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWinnipeg.Location = New System.Drawing.Point(26, 301)
        Me.lblWinnipeg.Name = "lblWinnipeg"
        Me.lblWinnipeg.Size = New System.Drawing.Size(110, 25)
        Me.lblWinnipeg.TabIndex = 4
        Me.lblWinnipeg.Text = "Winnipeg"
        '
        'lblToronto
        '
        Me.lblToronto.AutoSize = True
        Me.lblToronto.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblToronto.Location = New System.Drawing.Point(26, 358)
        Me.lblToronto.Name = "lblToronto"
        Me.lblToronto.Size = New System.Drawing.Size(93, 25)
        Me.lblToronto.TabIndex = 5
        Me.lblToronto.Text = "Toronto"
        '
        'lblHalifax
        '
        Me.lblHalifax.AutoSize = True
        Me.lblHalifax.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHalifax.Location = New System.Drawing.Point(26, 409)
        Me.lblHalifax.Name = "lblHalifax"
        Me.lblHalifax.Size = New System.Drawing.Size(85, 25)
        Me.lblHalifax.TabIndex = 6
        Me.lblHalifax.Text = "Halifax"
        '
        'txtEnterTime
        '
        Me.txtEnterTime.Location = New System.Drawing.Point(529, 68)
        Me.txtEnterTime.Name = "txtEnterTime"
        Me.txtEnterTime.Size = New System.Drawing.Size(100, 20)
        Me.txtEnterTime.TabIndex = 7
        '
        'txtOttawa
        '
        Me.txtOttawa.Location = New System.Drawing.Point(529, 129)
        Me.txtOttawa.Name = "txtOttawa"
        Me.txtOttawa.Size = New System.Drawing.Size(100, 20)
        Me.txtOttawa.TabIndex = 8
        '
        'txtVictoria
        '
        Me.txtVictoria.Location = New System.Drawing.Point(529, 186)
        Me.txtVictoria.Name = "txtVictoria"
        Me.txtVictoria.Size = New System.Drawing.Size(100, 20)
        Me.txtVictoria.TabIndex = 9
        '
        'txtEdmonton
        '
        Me.txtEdmonton.Location = New System.Drawing.Point(529, 246)
        Me.txtEdmonton.Name = "txtEdmonton"
        Me.txtEdmonton.Size = New System.Drawing.Size(100, 20)
        Me.txtEdmonton.TabIndex = 10
        '
        'txtWinnipeg
        '
        Me.txtWinnipeg.Location = New System.Drawing.Point(529, 306)
        Me.txtWinnipeg.Name = "txtWinnipeg"
        Me.txtWinnipeg.Size = New System.Drawing.Size(100, 20)
        Me.txtWinnipeg.TabIndex = 11
        '
        'txtToronto
        '
        Me.txtToronto.Location = New System.Drawing.Point(529, 363)
        Me.txtToronto.Name = "txtToronto"
        Me.txtToronto.Size = New System.Drawing.Size(100, 20)
        Me.txtToronto.TabIndex = 12
        '
        'txtHalifax
        '
        Me.txtHalifax.Location = New System.Drawing.Point(529, 414)
        Me.txtHalifax.Name = "txtHalifax"
        Me.txtHalifax.Size = New System.Drawing.Size(100, 20)
        Me.txtHalifax.TabIndex = 13
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(286, 450)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(75, 23)
        Me.btnDisplay.TabIndex = 14
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(641, 485)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.txtHalifax)
        Me.Controls.Add(Me.txtToronto)
        Me.Controls.Add(Me.txtWinnipeg)
        Me.Controls.Add(Me.txtEdmonton)
        Me.Controls.Add(Me.txtVictoria)
        Me.Controls.Add(Me.txtOttawa)
        Me.Controls.Add(Me.txtEnterTime)
        Me.Controls.Add(Me.lblHalifax)
        Me.Controls.Add(Me.lblToronto)
        Me.Controls.Add(Me.lblWinnipeg)
        Me.Controls.Add(Me.lblEdmonton)
        Me.Controls.Add(Me.lblVictoria)
        Me.Controls.Add(Me.lblOttawa)
        Me.Controls.Add(Me.lblEnterTime)
        Me.Name = "Form1"
        Me.Text = "Good Times"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblEnterTime As Label
    Friend WithEvents lblOttawa As Label
    Friend WithEvents lblVictoria As Label
    Friend WithEvents lblEdmonton As Label
    Friend WithEvents lblWinnipeg As Label
    Friend WithEvents lblToronto As Label
    Friend WithEvents lblHalifax As Label
    Friend WithEvents txtEnterTime As TextBox
    Friend WithEvents txtOttawa As TextBox
    Friend WithEvents txtVictoria As TextBox
    Friend WithEvents txtEdmonton As TextBox
    Friend WithEvents txtWinnipeg As TextBox
    Friend WithEvents txtToronto As TextBox
    Friend WithEvents txtHalifax As TextBox
    Friend WithEvents btnDisplay As Button
End Class
