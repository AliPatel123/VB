﻿Public Class Form1
    Dim Ottawa As Integer
    Dim Victoria As Integer
    Dim Winnipeg As Integer
    Dim Toronto As Integer
    Dim Halifax As Integer
    Dim Edmonton As Integer
    Dim EnterTime As Integer
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        EnterTime = txtEnterTime.Text

        Ottawa = EnterTime

        Toronto = EnterTime

        If EnterTime < 100 Then
            Winnipeg = 2460 - (60 - EnterTime)
        ElseIf EnterTime > 100 Then
            Winnipeg = EnterTime - 100
        ElseIf EnterTime = 100 Then
            Winnipeg = 2400
        End If

        If EnterTime < 300 Then
            Victoria = 2460 - (360 - EnterTime)
        ElseIf EnterTime > 300 Then
            Victoria = EnterTime - 300
        ElseIf EnterTime = 100 Then
            Victoria = 2200
        End If

        If EnterTime < 200 Then
            Edmonton = 2460 - (260 - EnterTime)
        ElseIf EnterTime > 200 Then
            Edmonton = EnterTime - 200
        ElseIf EnterTime = 100 Then
            Edmonton = 2300
        End If

        If EnterTime < 300 Then
            Halifax = 2460 - (360 - EnterTime)
        ElseIf EnterTime > 300 Then
            Halifax = EnterTime - 300
        ElseIf EnterTime = 2400 Then
            Halifax = 100
        End If

        txtOttawa.Text = Ottawa
        txtToronto.Text = Toronto
        txtEdmonton.Text = Edmonton
        txtVictoria.Text = Victoria
        txtWinnipeg.Text = Winnipeg
        txtHalifax.Text = Halifax
    End Sub
End Class
