﻿Module Module1

    Sub Main()
        Dim intbottles As Integer = 100
        Do While intbottles > 0
            intbottles -= 1
            Console.WriteLine(intbottles & " bottles of beer on the wall, " & intbottles & " bottles of beer. Take one down, pass it around, " & (intbottles - 1) & " bottles of beer on the wall.")
        Loop
        Console.ReadLine()
    End Sub

End Module
