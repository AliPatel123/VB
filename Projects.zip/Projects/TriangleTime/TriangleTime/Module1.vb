﻿Module Module1

    Sub Main()
        Dim inta1, inta2, inta3 As Integer 'Three Angles
        inta1 = Console.ReadLine
        inta2 = Console.ReadLine
        inta3 = Console.ReadLine

        If (inta1 + inta2 + inta3 = 180) Then
            If (inta1 = inta2 And inta2 = inta3) Then
                Console.WriteLine("Equilateral")
            ElseIf (inta1 = inta2 Or inta2 = inta3 Or inta1 = inta3) Then
                Console.WriteLine("Isosceles")
            Else
                Console.WriteLine("Scalene")
            End If
        Else
            Console.WriteLine("Error")
        End If

        Console.ReadLine()

    End Sub

End Module
