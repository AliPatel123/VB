﻿Module Module1

    Sub Main()
        'Here the conditions are checked in the beginning
        'keep on ask the user to enter an even number until he enter an
        'odd number
        Dim intNumber As Integer
        Console.WriteLine("Enter a Number")
        intNumber = Console.ReadLine
        Do While (intNumber Mod 2 = 0)
            'This loop will execute if  the Condition is True
            Console.WriteLine(intNumber)
            Console.WriteLine("Enter a Number")
            intNumber = Console.ReadLine

        Loop
        Console.WriteLine("The Do While  Loop End Here")

        intNumber = Console.ReadLine
        Do Until (intNumber Mod 2 = 0)
            'Do  Loop Excutes if  the condition is FALSE
            Console.WriteLine(intNumber)
            Console.WriteLine("Enter a Number")
            intNumber = Console.ReadLine
        Loop
        Console.WriteLine("The Do Until Loop End Here")
        'Console.ReadLine()

        'Do Loop where the Condition is checked at the end
        intNumber = Console.ReadLine

    End Sub

End Module
