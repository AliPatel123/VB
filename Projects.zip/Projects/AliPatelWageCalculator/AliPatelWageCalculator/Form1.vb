﻿Public Class Form1
    Dim Wage As Double 'Declaring the Wage as a double variable
    Dim Hours As Double 'Declaring the Hours Worked as a double variable
    Dim Gross As Double 'Declaring the Gross income as a double variable
    Dim Net As Double 'Declaring the Net income as a double variable
    Dim Tax As Double 'Declaring the Tax as a double variable
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Wage = txtWage.Text 'Assigning the variable wage to the text box "txtWage"
        Hours = txtHours.Text 'Assigning the variable Hours to the text box "txtHours"
        If Hours <= 40 Then 'Calculating regular work pay
            Gross = Hours * Wage
        ElseIf Hours > 40 Then 'Calculating overtime work pay
            Gross = (40 * Wage) + ((Hours - 40) * Wage * 1.5)
        End If
        Tax = Gross * 0.15 'Multiplying by 0.15 as that is the tax
        Net = Gross - Tax 'Deducting tax from the gross income to get the net income
        lblTaxDisplay.Text = "$" & Tax ' Displaying the tax
        lblGrossDisplay.Text = "$" & Gross 'Displaying the gross income
        lblNetDisplay.Text = "$" & Net 'Displaying the net income
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtWage.Clear() 'Clearing the text in the Wage textbox
        txtHours.Clear() 'Clearing the text in the Hours textbox
        lblTaxDisplay.Text = "" 'Clearing the text in the tax display label
        lblGrossDisplay.Text = "" 'Clearing the text in the gross income display label
        lblNetDisplay.Text = "" 'Clearing the text in the net income display label
    End Sub
End Class