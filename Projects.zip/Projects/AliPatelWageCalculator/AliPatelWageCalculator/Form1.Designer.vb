﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblWage = New System.Windows.Forms.Label()
        Me.lblHours = New System.Windows.Forms.Label()
        Me.lblGross = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblNet = New System.Windows.Forms.Label()
        Me.lblGrossDisplay = New System.Windows.Forms.Label()
        Me.lblTaxDisplay = New System.Windows.Forms.Label()
        Me.lblNetDisplay = New System.Windows.Forms.Label()
        Me.txtHours = New System.Windows.Forms.TextBox()
        Me.txtWage = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblWage
        '
        resources.ApplyResources(Me.lblWage, "lblWage")
        Me.lblWage.Name = "lblWage"
        '
        'lblHours
        '
        resources.ApplyResources(Me.lblHours, "lblHours")
        Me.lblHours.Name = "lblHours"
        '
        'lblGross
        '
        resources.ApplyResources(Me.lblGross, "lblGross")
        Me.lblGross.Name = "lblGross"
        '
        'lblTax
        '
        resources.ApplyResources(Me.lblTax, "lblTax")
        Me.lblTax.Name = "lblTax"
        '
        'lblNet
        '
        resources.ApplyResources(Me.lblNet, "lblNet")
        Me.lblNet.Name = "lblNet"
        '
        'lblGrossDisplay
        '
        resources.ApplyResources(Me.lblGrossDisplay, "lblGrossDisplay")
        Me.lblGrossDisplay.Name = "lblGrossDisplay"
        '
        'lblTaxDisplay
        '
        resources.ApplyResources(Me.lblTaxDisplay, "lblTaxDisplay")
        Me.lblTaxDisplay.Name = "lblTaxDisplay"
        '
        'lblNetDisplay
        '
        resources.ApplyResources(Me.lblNetDisplay, "lblNetDisplay")
        Me.lblNetDisplay.Name = "lblNetDisplay"
        '
        'txtHours
        '
        resources.ApplyResources(Me.txtHours, "txtHours")
        Me.txtHours.Name = "txtHours"
        '
        'txtWage
        '
        resources.ApplyResources(Me.txtWage, "txtWage")
        Me.txtWage.Name = "txtWage"
        '
        'btnCalculate
        '
        resources.ApplyResources(Me.btnCalculate, "btnCalculate")
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        resources.ApplyResources(Me.btnClear, "btnClear")
        Me.btnClear.Name = "btnClear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtWage)
        Me.Controls.Add(Me.txtHours)
        Me.Controls.Add(Me.lblNetDisplay)
        Me.Controls.Add(Me.lblTaxDisplay)
        Me.Controls.Add(Me.lblGrossDisplay)
        Me.Controls.Add(Me.lblNet)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.lblGross)
        Me.Controls.Add(Me.lblHours)
        Me.Controls.Add(Me.lblWage)
        Me.Name = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblWage As Label
    Friend WithEvents lblHours As Label
    Friend WithEvents lblGross As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblNet As Label
    Friend WithEvents lblGrossDisplay As Label
    Friend WithEvents lblTaxDisplay As Label
    Friend WithEvents lblNetDisplay As Label
    Friend WithEvents txtHours As TextBox
    Friend WithEvents txtWage As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
End Class
