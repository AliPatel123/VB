﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAccNo = New System.Windows.Forms.Label()
        Me.lblStartingBalance = New System.Windows.Forms.Label()
        Me.lblCharges = New System.Windows.Forms.Label()
        Me.lblCredits = New System.Windows.Forms.Label()
        Me.lblCredit = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblRemainingCredit = New System.Windows.Forms.Label()
        Me.lblNewBalanceDisplay = New System.Windows.Forms.Label()
        Me.txtTotalCharges = New System.Windows.Forms.TextBox()
        Me.txtStartingBalance = New System.Windows.Forms.TextBox()
        Me.txtCreditLimit = New System.Windows.Forms.TextBox()
        Me.txtTotalCredits = New System.Windows.Forms.TextBox()
        Me.txtAccNo = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblAccNo
        '
        Me.lblAccNo.AutoSize = True
        Me.lblAccNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAccNo.Location = New System.Drawing.Point(12, 61)
        Me.lblAccNo.Name = "lblAccNo"
        Me.lblAccNo.Size = New System.Drawing.Size(192, 25)
        Me.lblAccNo.TabIndex = 0
        Me.lblAccNo.Text = "Account Number:"
        '
        'lblStartingBalance
        '
        Me.lblStartingBalance.AutoSize = True
        Me.lblStartingBalance.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartingBalance.Location = New System.Drawing.Point(12, 104)
        Me.lblStartingBalance.Name = "lblStartingBalance"
        Me.lblStartingBalance.Size = New System.Drawing.Size(193, 25)
        Me.lblStartingBalance.TabIndex = 1
        Me.lblStartingBalance.Text = "Starting Balance:"
        '
        'lblCharges
        '
        Me.lblCharges.AutoSize = True
        Me.lblCharges.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCharges.Location = New System.Drawing.Point(12, 148)
        Me.lblCharges.Name = "lblCharges"
        Me.lblCharges.Size = New System.Drawing.Size(167, 25)
        Me.lblCharges.TabIndex = 2
        Me.lblCharges.Text = "Total Charges:"
        '
        'lblCredits
        '
        Me.lblCredits.AutoSize = True
        Me.lblCredits.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCredits.Location = New System.Drawing.Point(12, 192)
        Me.lblCredits.Name = "lblCredits"
        Me.lblCredits.Size = New System.Drawing.Size(154, 25)
        Me.lblCredits.TabIndex = 3
        Me.lblCredits.Text = "Total Credits:"
        '
        'lblCredit
        '
        Me.lblCredit.AutoSize = True
        Me.lblCredit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCredit.Location = New System.Drawing.Point(12, 234)
        Me.lblCredit.Name = "lblCredit"
        Me.lblCredit.Size = New System.Drawing.Size(139, 25)
        Me.lblCredit.TabIndex = 4
        Me.lblCredit.Text = "Credit Limit:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 281)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(156, 25)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "New Balance:"
        '
        'lblRemainingCredit
        '
        Me.lblRemainingCredit.AutoSize = True
        Me.lblRemainingCredit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRemainingCredit.Location = New System.Drawing.Point(205, 341)
        Me.lblRemainingCredit.Name = "lblRemainingCredit"
        Me.lblRemainingCredit.Size = New System.Drawing.Size(0, 25)
        Me.lblRemainingCredit.TabIndex = 6
        '
        'lblNewBalanceDisplay
        '
        Me.lblNewBalanceDisplay.AutoSize = True
        Me.lblNewBalanceDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNewBalanceDisplay.Location = New System.Drawing.Point(483, 281)
        Me.lblNewBalanceDisplay.Name = "lblNewBalanceDisplay"
        Me.lblNewBalanceDisplay.Size = New System.Drawing.Size(0, 25)
        Me.lblNewBalanceDisplay.TabIndex = 7
        '
        'txtTotalCharges
        '
        Me.txtTotalCharges.Location = New System.Drawing.Point(488, 153)
        Me.txtTotalCharges.Name = "txtTotalCharges"
        Me.txtTotalCharges.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalCharges.TabIndex = 8
        '
        'txtStartingBalance
        '
        Me.txtStartingBalance.Location = New System.Drawing.Point(488, 109)
        Me.txtStartingBalance.Name = "txtStartingBalance"
        Me.txtStartingBalance.Size = New System.Drawing.Size(100, 20)
        Me.txtStartingBalance.TabIndex = 9
        '
        'txtCreditLimit
        '
        Me.txtCreditLimit.Location = New System.Drawing.Point(488, 239)
        Me.txtCreditLimit.Name = "txtCreditLimit"
        Me.txtCreditLimit.Size = New System.Drawing.Size(100, 20)
        Me.txtCreditLimit.TabIndex = 10
        '
        'txtTotalCredits
        '
        Me.txtTotalCredits.Location = New System.Drawing.Point(488, 197)
        Me.txtTotalCredits.Name = "txtTotalCredits"
        Me.txtTotalCredits.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalCredits.TabIndex = 11
        '
        'txtAccNo
        '
        Me.txtAccNo.Location = New System.Drawing.Point(488, 66)
        Me.txtAccNo.Name = "txtAccNo"
        Me.txtAccNo.Size = New System.Drawing.Size(100, 20)
        Me.txtAccNo.TabIndex = 12
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(362, 384)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 13
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(129, 384)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 14
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 429)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtAccNo)
        Me.Controls.Add(Me.txtTotalCredits)
        Me.Controls.Add(Me.txtCreditLimit)
        Me.Controls.Add(Me.txtStartingBalance)
        Me.Controls.Add(Me.txtTotalCharges)
        Me.Controls.Add(Me.lblNewBalanceDisplay)
        Me.Controls.Add(Me.lblRemainingCredit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblCredit)
        Me.Controls.Add(Me.lblCredits)
        Me.Controls.Add(Me.lblCharges)
        Me.Controls.Add(Me.lblStartingBalance)
        Me.Controls.Add(Me.lblAccNo)
        Me.Name = "Form1"
        Me.Text = "Credit Checker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAccNo As Label
    Friend WithEvents lblStartingBalance As Label
    Friend WithEvents lblCharges As Label
    Friend WithEvents lblCredits As Label
    Friend WithEvents lblCredit As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblRemainingCredit As Label
    Friend WithEvents lblNewBalanceDisplay As Label
    Friend WithEvents txtTotalCharges As TextBox
    Friend WithEvents txtStartingBalance As TextBox
    Friend WithEvents txtCreditLimit As TextBox
    Friend WithEvents txtTotalCredits As TextBox
    Friend WithEvents txtAccNo As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
End Class
