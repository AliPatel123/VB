﻿Public Class Form1
    Dim Balance As Double
    Dim Credits As Double
    Dim Charges As Double
    Dim CreditLimit As Double
    Dim NewBalance As Double

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Balance = txtStartingBalance.Text
        Credits = txtTotalCredits.Text
        Charges = txtTotalCharges.Text
        CreditLimit = txtCreditLimit.Text
        NewBalance = Balance - Credits + Charges
        lblNewBalanceDisplay.Text = "$" & NewBalance
        lblRemainingCredit.Text = "Remaining Credit: $" & (CreditLimit - NewBalance)
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtAccNo.Clear()
        txtCreditLimit.Clear()
        txtStartingBalance.Clear()
        txtTotalCharges.Clear()
        txtTotalCredits.Clear()
        lblNewBalanceDisplay.Text = ""
        lblRemainingCredit.Text = ""
    End Sub
End Class
