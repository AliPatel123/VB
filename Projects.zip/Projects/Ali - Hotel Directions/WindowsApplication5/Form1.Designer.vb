﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.picHotel = New System.Windows.Forms.PictureBox()
        Me.lblHighway = New System.Windows.Forms.Label()
        Me.lblAirport = New System.Windows.Forms.Label()
        Me.lblHotel = New System.Windows.Forms.Label()
        Me.btnDirections = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblDirections = New System.Windows.Forms.Label()
        Me.lblExit = New System.Windows.Forms.Label()
        CType(Me.picHotel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(290, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(239, 25)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Directions To Old Mill"
        '
        'picHotel
        '
        Me.picHotel.Image = CType(resources.GetObject("picHotel.Image"), System.Drawing.Image)
        Me.picHotel.InitialImage = CType(resources.GetObject("picHotel.InitialImage"), System.Drawing.Image)
        Me.picHotel.Location = New System.Drawing.Point(-12, 52)
        Me.picHotel.Name = "picHotel"
        Me.picHotel.Size = New System.Drawing.Size(950, 472)
        Me.picHotel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picHotel.TabIndex = 1
        Me.picHotel.TabStop = False
        '
        'lblHighway
        '
        Me.lblHighway.AutoSize = True
        Me.lblHighway.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHighway.Location = New System.Drawing.Point(453, 139)
        Me.lblHighway.Name = "lblHighway"
        Me.lblHighway.Size = New System.Drawing.Size(101, 25)
        Me.lblHighway.TabIndex = 2
        Me.lblHighway.Text = "Highway"
        '
        'lblAirport
        '
        Me.lblAirport.AutoSize = True
        Me.lblAirport.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAirport.Location = New System.Drawing.Point(12, 177)
        Me.lblAirport.Name = "lblAirport"
        Me.lblAirport.Size = New System.Drawing.Size(82, 25)
        Me.lblAirport.TabIndex = 6
        Me.lblAirport.Text = "Airport"
        '
        'lblHotel
        '
        Me.lblHotel.AutoSize = True
        Me.lblHotel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHotel.Location = New System.Drawing.Point(731, 382)
        Me.lblHotel.Name = "lblHotel"
        Me.lblHotel.Size = New System.Drawing.Size(67, 25)
        Me.lblHotel.TabIndex = 7
        Me.lblHotel.Text = "Hotel"
        '
        'btnDirections
        '
        Me.btnDirections.Location = New System.Drawing.Point(163, 723)
        Me.btnDirections.Name = "btnDirections"
        Me.btnDirections.Size = New System.Drawing.Size(140, 33)
        Me.btnDirections.TabIndex = 8
        Me.btnDirections.Text = "Directions"
        Me.btnDirections.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(613, 723)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(140, 33)
        Me.btnClose.TabIndex = 10
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblDirections
        '
        Me.lblDirections.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDirections.Location = New System.Drawing.Point(104, 527)
        Me.lblDirections.Name = "lblDirections"
        Me.lblDirections.Size = New System.Drawing.Size(668, 193)
        Me.lblDirections.TabIndex = 11
        Me.lblDirections.Text = resources.GetString("lblDirections.Text")
        Me.lblDirections.Visible = False
        '
        'lblExit
        '
        Me.lblExit.AutoSize = True
        Me.lblExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExit.Location = New System.Drawing.Point(290, 364)
        Me.lblExit.Name = "lblExit"
        Me.lblExit.Size = New System.Drawing.Size(52, 25)
        Me.lblExit.TabIndex = 4
        Me.lblExit.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(950, 768)
        Me.Controls.Add(Me.lblDirections)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnDirections)
        Me.Controls.Add(Me.lblHotel)
        Me.Controls.Add(Me.lblAirport)
        Me.Controls.Add(Me.lblExit)
        Me.Controls.Add(Me.lblHighway)
        Me.Controls.Add(Me.picHotel)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "Form1"
        Me.Text = "Hotel Directions"
        CType(Me.picHotel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents picHotel As PictureBox
    Friend WithEvents lblHighway As Label
    Friend WithEvents lblAirport As Label
    Friend WithEvents lblHotel As Label
    Friend WithEvents btnDirections As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lblDirections As Label
    Friend WithEvents lblExit As Label
End Class
