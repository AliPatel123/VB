﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblTitle.Click

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub

    Private Sub picHotel_Click(sender As Object, e As EventArgs) Handles picHotel.Click

    End Sub

    Private Sub btnDirections_Click(sender As Object, e As EventArgs) Handles btnDirections.Click
        lblDirections.Visible = True
    End Sub
End Class
