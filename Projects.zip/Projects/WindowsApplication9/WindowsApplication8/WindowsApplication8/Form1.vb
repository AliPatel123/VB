﻿Public Class Form1
    Dim randin As Integer = Int(Rnd() * 10)

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        Dim intGenerate As Integer = txtInput.Text
        If randin = intGenerate Then
            lblDiplay.Text = "Correct!"
        ElseIf randin < intGenerate Then
            lblDiplay.Text = "Too High!"
        ElseIf randin > intGenerate Then
            lblDiplay.Text = "Too Low!"
        End If
    End Sub
End Class
