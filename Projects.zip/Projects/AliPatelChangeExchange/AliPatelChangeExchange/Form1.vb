﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim Toonies, Loonies, Quarters, Dimes, Nickels, Pennies As Integer 'Declaring Variables
        Dim Cents As Double = txtCurrency.Text 'Assigning inout 
        Dim Currency As Integer = Cents * 100 'Converting to cents
        txtAmount.Text = txtCurrency.Text 'Assigning input as amount
        Toonies = (Currency - Currency Mod 200) \ 200 'Calculating Toonies
        Loonies = (Currency Mod 200 - Currency Mod 100) \ 100 'Calculating Loonies
        Quarters = (Currency Mod 100 - Currency Mod 25) \ 25 'Calculating Quarters
        Dimes = (Currency Mod 25 - Currency Mod 10) \ 10  'Calculating Dimes
        Nickels = (Currency Mod 10 - Currency Mod 5) \ 5  'Calculating Nickels
        Pennies = (Currency Mod 5 - Currency Mod 1)  'Calculating Pennies

        txtToonies.Text = Toonies 'Assigning to the label Toonies
        txtLoonies.Text = Loonies 'Assigning to the label Loonies
        txtQuarters.Text = Quarters 'Assigning to the label Quarters
        txtDimes.Text = Dimes 'Assigning to the label Dimes
        txtNickels.Text = Nickels 'Assigning to the label Nickels
        txtPennies.Text = Pennies 'Assigning to the label Pennies

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
