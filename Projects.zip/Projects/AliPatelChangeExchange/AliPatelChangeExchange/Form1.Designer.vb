﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblChEx = New System.Windows.Forms.Label()
        Me.lblCurrency = New System.Windows.Forms.Label()
        Me.lblAmt = New System.Windows.Forms.Label()
        Me.txtCurrency = New System.Windows.Forms.TextBox()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.lblAmount = New System.Windows.Forms.Label()
        Me.lblQuarters = New System.Windows.Forms.Label()
        Me.lblDimes = New System.Windows.Forms.Label()
        Me.lblNickles = New System.Windows.Forms.Label()
        Me.lblPennies = New System.Windows.Forms.Label()
        Me.lblLoonies = New System.Windows.Forms.Label()
        Me.lblToonies = New System.Windows.Forms.Label()
        Me.txtToonies = New System.Windows.Forms.TextBox()
        Me.txtPennies = New System.Windows.Forms.TextBox()
        Me.txtDimes = New System.Windows.Forms.TextBox()
        Me.txtLoonies = New System.Windows.Forms.TextBox()
        Me.txtNickels = New System.Windows.Forms.TextBox()
        Me.txtQuarters = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblChEx
        '
        Me.lblChEx.AutoSize = True
        Me.lblChEx.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChEx.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblChEx.Location = New System.Drawing.Point(103, 54)
        Me.lblChEx.Name = "lblChEx"
        Me.lblChEx.Size = New System.Drawing.Size(204, 25)
        Me.lblChEx.TabIndex = 0
        Me.lblChEx.Text = "Change Exchange"
        '
        'lblCurrency
        '
        Me.lblCurrency.AutoSize = True
        Me.lblCurrency.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency.Location = New System.Drawing.Point(12, 115)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(177, 25)
        Me.lblCurrency.TabIndex = 1
        Me.lblCurrency.Text = "Enter Currency:"
        '
        'lblAmt
        '
        Me.lblAmt.AutoSize = True
        Me.lblAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAmt.Location = New System.Drawing.Point(14, 140)
        Me.lblAmt.Name = "lblAmt"
        Me.lblAmt.Size = New System.Drawing.Size(193, 25)
        Me.lblAmt.TabIndex = 2
        Me.lblAmt.Text = "Amount (xxxx.xx)"
        '
        'txtCurrency
        '
        Me.txtCurrency.Location = New System.Drawing.Point(207, 115)
        Me.txtCurrency.Name = "txtCurrency"
        Me.txtCurrency.Size = New System.Drawing.Size(100, 20)
        Me.txtCurrency.TabIndex = 3
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(212, 188)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(100, 20)
        Me.txtAmount.TabIndex = 4
        '
        'lblAmount
        '
        Me.lblAmount.AutoSize = True
        Me.lblAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAmount.Location = New System.Drawing.Point(12, 188)
        Me.lblAmount.Name = "lblAmount"
        Me.lblAmount.Size = New System.Drawing.Size(91, 25)
        Me.lblAmount.TabIndex = 5
        Me.lblAmount.Text = "Amount"
        '
        'lblQuarters
        '
        Me.lblQuarters.AutoSize = True
        Me.lblQuarters.Location = New System.Drawing.Point(16, 260)
        Me.lblQuarters.Name = "lblQuarters"
        Me.lblQuarters.Size = New System.Drawing.Size(47, 13)
        Me.lblQuarters.TabIndex = 6
        Me.lblQuarters.Text = "Quarters"
        '
        'lblDimes
        '
        Me.lblDimes.AutoSize = True
        Me.lblDimes.Location = New System.Drawing.Point(16, 312)
        Me.lblDimes.Name = "lblDimes"
        Me.lblDimes.Size = New System.Drawing.Size(36, 13)
        Me.lblDimes.TabIndex = 7
        Me.lblDimes.Text = "Dimes"
        '
        'lblNickles
        '
        Me.lblNickles.AutoSize = True
        Me.lblNickles.Location = New System.Drawing.Point(150, 260)
        Me.lblNickles.Name = "lblNickles"
        Me.lblNickles.Size = New System.Drawing.Size(42, 13)
        Me.lblNickles.TabIndex = 8
        Me.lblNickles.Text = "Nickles"
        '
        'lblPennies
        '
        Me.lblPennies.AutoSize = True
        Me.lblPennies.Location = New System.Drawing.Point(150, 312)
        Me.lblPennies.Name = "lblPennies"
        Me.lblPennies.Size = New System.Drawing.Size(45, 13)
        Me.lblPennies.TabIndex = 9
        Me.lblPennies.Text = "Pennies"
        '
        'lblLoonies
        '
        Me.lblLoonies.AutoSize = True
        Me.lblLoonies.Location = New System.Drawing.Point(268, 260)
        Me.lblLoonies.Name = "lblLoonies"
        Me.lblLoonies.Size = New System.Drawing.Size(44, 13)
        Me.lblLoonies.TabIndex = 10
        Me.lblLoonies.Text = "Loonies"
        '
        'lblToonies
        '
        Me.lblToonies.AutoSize = True
        Me.lblToonies.Location = New System.Drawing.Point(268, 312)
        Me.lblToonies.Name = "lblToonies"
        Me.lblToonies.Size = New System.Drawing.Size(45, 13)
        Me.lblToonies.TabIndex = 11
        Me.lblToonies.Text = "Toonies"
        '
        'txtToonies
        '
        Me.txtToonies.Location = New System.Drawing.Point(319, 312)
        Me.txtToonies.Name = "txtToonies"
        Me.txtToonies.Size = New System.Drawing.Size(75, 20)
        Me.txtToonies.TabIndex = 12
        '
        'txtPennies
        '
        Me.txtPennies.Location = New System.Drawing.Point(198, 312)
        Me.txtPennies.Name = "txtPennies"
        Me.txtPennies.Size = New System.Drawing.Size(64, 20)
        Me.txtPennies.TabIndex = 13
        '
        'txtDimes
        '
        Me.txtDimes.Location = New System.Drawing.Point(69, 305)
        Me.txtDimes.Name = "txtDimes"
        Me.txtDimes.Size = New System.Drawing.Size(75, 20)
        Me.txtDimes.TabIndex = 14
        '
        'txtLoonies
        '
        Me.txtLoonies.Location = New System.Drawing.Point(318, 260)
        Me.txtLoonies.Name = "txtLoonies"
        Me.txtLoonies.Size = New System.Drawing.Size(76, 20)
        Me.txtLoonies.TabIndex = 15
        '
        'txtNickels
        '
        Me.txtNickels.Location = New System.Drawing.Point(198, 260)
        Me.txtNickels.Name = "txtNickels"
        Me.txtNickels.Size = New System.Drawing.Size(64, 20)
        Me.txtNickels.TabIndex = 16
        '
        'txtQuarters
        '
        Me.txtQuarters.Location = New System.Drawing.Point(69, 257)
        Me.txtQuarters.Name = "txtQuarters"
        Me.txtQuarters.Size = New System.Drawing.Size(74, 20)
        Me.txtQuarters.TabIndex = 17
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(108, 225)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 18
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(232, 225)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 19
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(406, 354)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtQuarters)
        Me.Controls.Add(Me.txtNickels)
        Me.Controls.Add(Me.txtLoonies)
        Me.Controls.Add(Me.txtDimes)
        Me.Controls.Add(Me.txtPennies)
        Me.Controls.Add(Me.txtToonies)
        Me.Controls.Add(Me.lblToonies)
        Me.Controls.Add(Me.lblLoonies)
        Me.Controls.Add(Me.lblPennies)
        Me.Controls.Add(Me.lblNickles)
        Me.Controls.Add(Me.lblDimes)
        Me.Controls.Add(Me.lblQuarters)
        Me.Controls.Add(Me.lblAmount)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.txtCurrency)
        Me.Controls.Add(Me.lblAmt)
        Me.Controls.Add(Me.lblCurrency)
        Me.Controls.Add(Me.lblChEx)
        Me.Name = "Form1"
        Me.Text = "ChangeCalculator_Ali_Patel"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblChEx As Label
    Friend WithEvents lblCurrency As Label
    Friend WithEvents lblAmt As Label
    Friend WithEvents txtCurrency As TextBox
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblAmount As Label
    Friend WithEvents lblQuarters As Label
    Friend WithEvents lblDimes As Label
    Friend WithEvents lblNickles As Label
    Friend WithEvents lblPennies As Label
    Friend WithEvents lblLoonies As Label
    Friend WithEvents lblToonies As Label
    Friend WithEvents txtToonies As TextBox
    Friend WithEvents txtPennies As TextBox
    Friend WithEvents txtDimes As TextBox
    Friend WithEvents txtLoonies As TextBox
    Friend WithEvents txtNickels As TextBox
    Friend WithEvents txtQuarters As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
End Class
