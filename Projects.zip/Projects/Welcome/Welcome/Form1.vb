﻿Public Class Form1
    Dim Attempts As Integer = 0

    Private Sub btnOkay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOkay.Click
        Dim strUserID As String = txtUserID.Text
        Dim strPassword As String = txtPassword.Text
        Dim strID As String = "Computer"
        Dim strPwd As String = "Science"
        Dim strID2 As String = "Ali"
        Dim strPwd2 As String = "Patel"
        Dim strID3 As String = "Mr"
        Dim strPwd3 As String = "Jeg"

        If strUserID = strID And strPassword = strPwd Or strUserID = strID2 And strPassword = strPwd2 Or strUserID = strID3 And strPassword = strPwd3 Then
            MsgBox("Welcome!")
        ElseIf strUserID <> strID And strPassword = strPwd Or strUserID <> strID2 And strPassword = strPwd2 Or strUserID <> strID3 And strPassword = strPwd3 Then
            MsgBox("Incorrect ID")
            txtUserID.Clear()
            txtPassword.Clear()
            Attempts = Attempts + 1
        ElseIf strUserID = strID And strPassword <> strPwd Or strUserID = strID2 And strPassword <> strPwd2 Or strUserID = strID3 And strPassword <> strPwd3 Then
            MsgBox("Incorrect Password")
            txtUserID.Clear()
            txtPassword.Clear()
            Attempts = Attempts + 1
        ElseIf strUserID <> strID And strPassword <> strPwd Or strUserID <> strID2 And strPassword <> strPwd2 Or strUserID <> strID3 And strPassword <> strPwd3 Then
            MsgBox("Incorrect ID and password")
            txtUserID.Clear()
            txtPassword.Clear()
            Attempts = Attempts + 1
        End If
        If Attempts = 3 Then
            MsgBox("You are now locked out!")
        End If
    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class