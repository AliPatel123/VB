﻿Public Class Form1
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim intmonth As Integer
        intmonth = txtMonth.Text

        Select Case intmonth
            Case 1 : txtDisplay.Text = "January"
            Case 2 : txtDisplay.Text = "February"
            Case 3 : txtDisplay.Text = "March"
            Case 4 : txtDisplay.Text = "April"

        End Select


    End Sub
End Class
