﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblIncome = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtGrossIncome = New System.Windows.Forms.TextBox()
        Me.txtTax = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(12, 31)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(199, 25)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Enter Your Name:"
        '
        'lblIncome
        '
        Me.lblIncome.AutoSize = True
        Me.lblIncome.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIncome.Location = New System.Drawing.Point(12, 97)
        Me.lblIncome.Name = "lblIncome"
        Me.lblIncome.Size = New System.Drawing.Size(342, 25)
        Me.lblIncome.TabIndex = 1
        Me.lblIncome.Text = "Enter Your 2016 Gross Income:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(468, 36)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 2
        '
        'txtGrossIncome
        '
        Me.txtGrossIncome.Location = New System.Drawing.Point(468, 102)
        Me.txtGrossIncome.Name = "txtGrossIncome"
        Me.txtGrossIncome.Size = New System.Drawing.Size(100, 20)
        Me.txtGrossIncome.TabIndex = 3
        '
        'txtTax
        '
        Me.txtTax.Location = New System.Drawing.Point(468, 221)
        Me.txtTax.Name = "txtTax"
        Me.txtTax.Size = New System.Drawing.Size(100, 20)
        Me.txtTax.TabIndex = 4
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(249, 156)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 5
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(23, 216)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(286, 25)
        Me.lblTax.TabIndex = 6
        Me.lblTax.Text = "Your 2016 Federal Tax Is:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(580, 341)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtTax)
        Me.Controls.Add(Me.txtGrossIncome)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblIncome)
        Me.Controls.Add(Me.lblName)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblName As Label
    Friend WithEvents lblIncome As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtGrossIncome As TextBox
    Friend WithEvents txtTax As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblTax As Label
End Class
