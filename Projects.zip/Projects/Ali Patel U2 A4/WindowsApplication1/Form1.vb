﻿Public Class Form1
    Dim Tax As Double
    Dim Tax2 As Double
    Dim Tax3 As Double
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim GrossIncome As Double = txtGrossIncome.Text

        If GrossIncome <= 45282 Then
            Tax = txtGrossIncome.Text * 0.15

        ElseIf GrossIncome > 45282 And GrossIncome <= 90563 Then
            Tax2 = txtGrossIncome.Text - 45282
            Tax2 = Tax2 * 0.205
            Tax3 = 45282 * 0.15
            Tax = Tax2 + Tax3

        ElseIf GrossIncome > 90563 And GrossIncome <= 140388 Then
            Tax2 = txtGrossIncome.Text - 90563
            Tax2 = Tax2 * 0.26
            Tax3 = (45282 * 0.15) + (45281 * 0.205)
            Tax = Tax2 + Tax3

        ElseIf GrossIncome > 140388 And GrossIncome <= 200000 Then
            Tax2 = txtGrossIncome.Text - 140388
            Tax2 = Tax2 * 0.29
            Tax3 = (45282 * 0.15) + (45281 * 0.205) + (49825 * 0.26)
            Tax = Tax2 + Tax3

        ElseIf GrossIncome > 200000 Then
            Tax2 = txtGrossIncome.Text - 200000
            Tax2 = Tax2 * 0.33
            Tax3 = (45282 * 0.15) + (45281 * 0.205) + (49825 * 0.26) + (59612 * 0.29)
            Tax = Tax2 + Tax3
        End If

        txtTax.Text = Tax

    End Sub
End Class
