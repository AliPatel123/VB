﻿Module Module1

    Sub Main()
        Dim strname As String
        strname = "Stephen Harper"
        Console.WriteLine(strname.Length)
        Console.WriteLine(strname(0))
        Console.WriteLine(strname(strname.Length - 1))
        Dim intcount As Integer
        For intcount = 1 To 10
            Console.WriteLine(intcount)
        Next
        Console.ReadLine()
    End Sub

End Module
