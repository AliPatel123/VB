﻿Module Module1
    Sub Main()
        Dim intnum As Integer = 48
        For i = 1 To intnum
            If 48 Mod i = 0 Then
                Console.Write(i & vbTab)
            End If

        Next
        Console.ReadLine()
    End Sub
End Module
