﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim Hangry As Boolean
        Hangry = False
        If Hangry = True Then
            lblDisplay.Text = "Call Pizza Hut"
        Else
            lblDisplay.Text = "Do Mr Jeg's Assignment"
        End If

    End Sub
End Class
