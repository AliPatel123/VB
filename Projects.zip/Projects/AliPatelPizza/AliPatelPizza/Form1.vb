﻿Public Class PizzaPriceCalculator
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim diameter, total As Decimal 'Declare the diameter and the total as decimal variables
        diameter = txtDiameter.Text 'Assign diameter to user input
        total = diameter * 0.5 + 2.5 'Input formula
        lblOutput.Text = "The cost of the pizza is: " & FormatCurrency(total) 'Display price
    End Sub
End Class