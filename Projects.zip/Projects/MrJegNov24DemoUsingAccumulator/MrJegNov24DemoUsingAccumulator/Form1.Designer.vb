﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtMarks = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblMarks = New System.Windows.Forms.Label()
        Me.lstName = New System.Windows.Forms.ListBox()
        Me.lstMarks = New System.Windows.Forms.ListBox()
        Me.lblAverage = New System.Windows.Forms.Label()
        Me.txtAverage = New System.Windows.Forms.TextBox()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(487, 47)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 0
        '
        'txtMarks
        '
        Me.txtMarks.Location = New System.Drawing.Point(487, 121)
        Me.txtMarks.Name = "txtMarks"
        Me.txtMarks.Size = New System.Drawing.Size(100, 20)
        Me.txtMarks.TabIndex = 1
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(3, 42)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(79, 25)
        Me.lblName.TabIndex = 2
        Me.lblName.Text = "Name:"
        '
        'lblMarks
        '
        Me.lblMarks.AutoSize = True
        Me.lblMarks.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMarks.Location = New System.Drawing.Point(3, 116)
        Me.lblMarks.Name = "lblMarks"
        Me.lblMarks.Size = New System.Drawing.Size(83, 25)
        Me.lblMarks.TabIndex = 3
        Me.lblMarks.Text = "Marks:"
        '
        'lstName
        '
        Me.lstName.FormattingEnabled = True
        Me.lstName.Location = New System.Drawing.Point(79, 164)
        Me.lstName.Name = "lstName"
        Me.lstName.Size = New System.Drawing.Size(120, 264)
        Me.lstName.TabIndex = 4
        '
        'lstMarks
        '
        Me.lstMarks.FormattingEnabled = True
        Me.lstMarks.Location = New System.Drawing.Point(382, 164)
        Me.lstMarks.Name = "lstMarks"
        Me.lstMarks.Size = New System.Drawing.Size(120, 264)
        Me.lstMarks.TabIndex = 5
        '
        'lblAverage
        '
        Me.lblAverage.AutoSize = True
        Me.lblAverage.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverage.Location = New System.Drawing.Point(74, 434)
        Me.lblAverage.Name = "lblAverage"
        Me.lblAverage.Size = New System.Drawing.Size(322, 25)
        Me.lblAverage.TabIndex = 6
        Me.lblAverage.Text = "The Average Of The Class Is:"
        '
        'txtAverage
        '
        Me.txtAverage.Location = New System.Drawing.Point(402, 434)
        Me.txtAverage.Name = "txtAverage"
        Me.txtAverage.Size = New System.Drawing.Size(100, 20)
        Me.txtAverage.TabIndex = 7
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(251, 295)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 8
        Me.btnEnter.Text = "Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(251, 405)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 9
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(599, 485)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.txtAverage)
        Me.Controls.Add(Me.lblAverage)
        Me.Controls.Add(Me.lstMarks)
        Me.Controls.Add(Me.lstName)
        Me.Controls.Add(Me.lblMarks)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtMarks)
        Me.Controls.Add(Me.txtName)
        Me.Name = "Form1"
        Me.Text = "AverageCalculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtName As TextBox
    Friend WithEvents txtMarks As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents lblMarks As Label
    Friend WithEvents lstName As ListBox
    Friend WithEvents lstMarks As ListBox
    Friend WithEvents lblAverage As Label
    Friend WithEvents txtAverage As TextBox
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnCalculate As Button
End Class
