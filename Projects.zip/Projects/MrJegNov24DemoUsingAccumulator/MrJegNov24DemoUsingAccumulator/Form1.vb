﻿Public Class Form1
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim intTotal As Integer = 0 'This Variable will accumulate the Marks total
        Dim intCount As Integer = 1 'A counter to keep track of 10 entries
        Dim Num As Integer = 0
        Do While (intCount <= 5)
            intTotal = intTotal + lstMarks.Items(Num)
            intCount = intCount + 1
            Num = Num + 1
        Loop
        txtAverage.Text = (intTotal / 5) 'To find and display the average
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim strName As String 'Name of each student
        Dim intMarks As Integer 'Marks of each student
        Dim intTotal As Integer = 0 'This Variable will accumulate the Marks total
        Dim intCount As Integer = 0 'A counter to keep track of 10 entries

        strName = txtName.Text
        lstName.Items.Add(strName)
        intMarks = txtMarks.Text
        lstMarks.Items.Add(intMarks)
    End Sub
End Class
