﻿Module Module1

    Sub Main()
        'Time for some god level giftedness
        Dim MrJeg As Integer = 0
        Do While True
            MrJeg += 1
            Console.WriteLine("I have been a programmer for " & MrJeg & " years sir!")
        Loop
    End Sub
End Module
