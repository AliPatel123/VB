﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FastFoodCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDrinks = New System.Windows.Forms.TextBox()
        Me.txtFries = New System.Windows.Forms.TextBox()
        Me.txtBurger = New System.Windows.Forms.TextBox()
        Me.lblTotalBeforeTax = New System.Windows.Forms.Label()
        Me.lblFinalTotal = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.lblTender = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtTender = New System.Windows.Forms.TextBox()
        Me.lblChange = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(199, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(385, 42)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fast Food Calculator"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(81, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(276, 25)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter Number Of Burgers"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(81, 107)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(247, 25)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Enter Number Of Fries"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(81, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(261, 25)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Enter Number Of Drinks"
        '
        'txtDrinks
        '
        Me.txtDrinks.Location = New System.Drawing.Point(484, 140)
        Me.txtDrinks.Name = "txtDrinks"
        Me.txtDrinks.Size = New System.Drawing.Size(100, 20)
        Me.txtDrinks.TabIndex = 4
        '
        'txtFries
        '
        Me.txtFries.Location = New System.Drawing.Point(484, 114)
        Me.txtFries.Name = "txtFries"
        Me.txtFries.Size = New System.Drawing.Size(100, 20)
        Me.txtFries.TabIndex = 5
        '
        'txtBurger
        '
        Me.txtBurger.Location = New System.Drawing.Point(484, 88)
        Me.txtBurger.Name = "txtBurger"
        Me.txtBurger.Size = New System.Drawing.Size(100, 20)
        Me.txtBurger.TabIndex = 6
        '
        'lblTotalBeforeTax
        '
        Me.lblTotalBeforeTax.AutoSize = True
        Me.lblTotalBeforeTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalBeforeTax.Location = New System.Drawing.Point(81, 238)
        Me.lblTotalBeforeTax.Name = "lblTotalBeforeTax"
        Me.lblTotalBeforeTax.Size = New System.Drawing.Size(0, 25)
        Me.lblTotalBeforeTax.TabIndex = 7
        '
        'lblFinalTotal
        '
        Me.lblFinalTotal.AutoSize = True
        Me.lblFinalTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinalTotal.Location = New System.Drawing.Point(81, 288)
        Me.lblFinalTotal.Name = "lblFinalTotal"
        Me.lblFinalTotal.Size = New System.Drawing.Size(0, 25)
        Me.lblFinalTotal.TabIndex = 8
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(81, 263)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(0, 25)
        Me.lblTax.TabIndex = 9
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(320, 337)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 10
        Me.btnEnter.Text = "Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lblTender
        '
        Me.lblTender.AutoSize = True
        Me.lblTender.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTender.Location = New System.Drawing.Point(81, 173)
        Me.lblTender.Name = "lblTender"
        Me.lblTender.Size = New System.Drawing.Size(198, 25)
        Me.lblTender.TabIndex = 11
        Me.lblTender.Text = "Amount Tendered"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(81, 213)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 25)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Change"
        '
        'txtTender
        '
        Me.txtTender.Location = New System.Drawing.Point(484, 178)
        Me.txtTender.Name = "txtTender"
        Me.txtTender.Size = New System.Drawing.Size(100, 20)
        Me.txtTender.TabIndex = 13
        '
        'lblChange
        '
        Me.lblChange.AutoSize = True
        Me.lblChange.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblChange.Location = New System.Drawing.Point(481, 213)
        Me.lblChange.Name = "lblChange"
        Me.lblChange.Size = New System.Drawing.Size(0, 25)
        Me.lblChange.TabIndex = 14
        '
        'FastFoodCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(750, 372)
        Me.Controls.Add(Me.lblChange)
        Me.Controls.Add(Me.txtTender)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblTender)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.lblFinalTotal)
        Me.Controls.Add(Me.lblTotalBeforeTax)
        Me.Controls.Add(Me.txtBurger)
        Me.Controls.Add(Me.txtFries)
        Me.Controls.Add(Me.txtDrinks)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FastFoodCalculator"
        Me.Text = "Fast Food Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtDrinks As TextBox
    Friend WithEvents txtFries As TextBox
    Friend WithEvents txtBurger As TextBox
    Friend WithEvents lblTotalBeforeTax As Label
    Friend WithEvents lblFinalTotal As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents lblTender As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtTender As TextBox
    Friend WithEvents lblChange As Label
End Class
