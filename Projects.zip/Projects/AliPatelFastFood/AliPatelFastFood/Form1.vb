﻿Public Class FastFoodCalculator
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim Burgers, Fries, Drinks, TotalBeforeTax, Tax, Tender, Change, FinalTotal As Decimal 'Set the items as variables

        Burgers = txtBurger.Text 'Assign burgers to the text box user input
        Fries = txtFries.Text 'Assign fries to the text box user input
        Drinks = txtDrinks.Text 'Assign drinks to the text box user input
        Tender = txtTender.Text 'Assign tender to the text box user input

        TotalBeforeTax = Burgers * 2.49 + Fries * 1.89 + Drinks * 0.99 ' Input formula
        Tax = TotalBeforeTax * 0.13 'Finding taxes
        FinalTotal = TotalBeforeTax + Tax 'Adding taxes to cost

        Change = Tender - FinalTotal 'Finding change
        lblChange.Text = FormatCurrency(Change, 2) 'Displaying change

        lblTotalBeforeTax.Text = "Total before Tax: " & FormatCurrency(TotalBeforeTax, 2) 'Displaying Total before tax
        lblTax.Text = "Tax: " & FormatCurrency(Tax, 2) 'Displaying tax
        lblFinalTotal.Text = "Final Total: " & FormatCurrency(FinalTotal, 2) 'Displaying Final tax

    End Sub
End Class
