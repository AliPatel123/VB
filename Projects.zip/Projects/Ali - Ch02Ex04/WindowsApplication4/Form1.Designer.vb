﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.rdbYale = New System.Windows.Forms.RadioButton()
        Me.rdbHarvard = New System.Windows.Forms.RadioButton()
        Me.rdbPrinceton = New System.Windows.Forms.RadioButton()
        Me.rdbMichigan = New System.Windows.Forms.RadioButton()
        Me.rdbSyracuse = New System.Windows.Forms.RadioButton()
        Me.lblDisplay = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'rdbYale
        '
        Me.rdbYale.AutoSize = True
        Me.rdbYale.Location = New System.Drawing.Point(24, 12)
        Me.rdbYale.Name = "rdbYale"
        Me.rdbYale.Size = New System.Drawing.Size(46, 17)
        Me.rdbYale.TabIndex = 0
        Me.rdbYale.TabStop = True
        Me.rdbYale.Text = "Yale"
        Me.rdbYale.UseVisualStyleBackColor = True
        '
        'rdbHarvard
        '
        Me.rdbHarvard.AutoSize = True
        Me.rdbHarvard.Location = New System.Drawing.Point(24, 75)
        Me.rdbHarvard.Name = "rdbHarvard"
        Me.rdbHarvard.Size = New System.Drawing.Size(63, 17)
        Me.rdbHarvard.TabIndex = 1
        Me.rdbHarvard.Text = "Harvard"
        Me.rdbHarvard.UseVisualStyleBackColor = True
        '
        'rdbPrinceton
        '
        Me.rdbPrinceton.AutoSize = True
        Me.rdbPrinceton.Location = New System.Drawing.Point(24, 147)
        Me.rdbPrinceton.Name = "rdbPrinceton"
        Me.rdbPrinceton.Size = New System.Drawing.Size(70, 17)
        Me.rdbPrinceton.TabIndex = 2
        Me.rdbPrinceton.TabStop = True
        Me.rdbPrinceton.Text = "Princeton"
        Me.rdbPrinceton.UseVisualStyleBackColor = True
        '
        'rdbMichigan
        '
        Me.rdbMichigan.AutoSize = True
        Me.rdbMichigan.Location = New System.Drawing.Point(24, 219)
        Me.rdbMichigan.Name = "rdbMichigan"
        Me.rdbMichigan.Size = New System.Drawing.Size(145, 17)
        Me.rdbMichigan.TabIndex = 3
        Me.rdbMichigan.TabStop = True
        Me.rdbMichigan.Text = "Michigan State University"
        Me.rdbMichigan.UseVisualStyleBackColor = True
        '
        'rdbSyracuse
        '
        Me.rdbSyracuse.AutoSize = True
        Me.rdbSyracuse.Location = New System.Drawing.Point(24, 287)
        Me.rdbSyracuse.Name = "rdbSyracuse"
        Me.rdbSyracuse.Size = New System.Drawing.Size(118, 17)
        Me.rdbSyracuse.TabIndex = 4
        Me.rdbSyracuse.TabStop = True
        Me.rdbSyracuse.Text = "Syracuse University"
        Me.rdbSyracuse.UseVisualStyleBackColor = True
        '
        'lblDisplay
        '
        Me.lblDisplay.AutoSize = True
        Me.lblDisplay.Location = New System.Drawing.Point(192, 51)
        Me.lblDisplay.Name = "lblDisplay"
        Me.lblDisplay.Size = New System.Drawing.Size(39, 13)
        Me.lblDisplay.TabIndex = 5
        Me.lblDisplay.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(436, 316)
        Me.Controls.Add(Me.lblDisplay)
        Me.Controls.Add(Me.rdbSyracuse)
        Me.Controls.Add(Me.rdbMichigan)
        Me.Controls.Add(Me.rdbPrinceton)
        Me.Controls.Add(Me.rdbHarvard)
        Me.Controls.Add(Me.rdbYale)
        Me.Name = "Form1"
        Me.Text = "School Information"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rdbYale As RadioButton
    Friend WithEvents rdbHarvard As RadioButton
    Friend WithEvents rdbPrinceton As RadioButton
    Friend WithEvents rdbMichigan As RadioButton
    Friend WithEvents rdbSyracuse As RadioButton
    Friend WithEvents lblDisplay As Label
End Class
