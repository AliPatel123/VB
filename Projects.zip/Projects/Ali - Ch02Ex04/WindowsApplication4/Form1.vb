﻿Public Class Form1

    Private Sub rdbHarvard_CheckedChanged(sender As Object, e As EventArgs) Handles rdbHarvard.CheckedChanged
        lblDisplay.Text = "Location:

                           City:  Cambridge
                           State: Massachusetts"
    End Sub

    Private Sub rdbPrinceton_CheckedChanged(sender As Object, e As EventArgs) Handles rdbPrinceton.CheckedChanged
        lblDisplay.Text = "Location:

                           City:  Princeton
                           State: New Jersey"
    End Sub

    Private Sub rdbSyracuse_CheckedChanged(sender As Object, e As EventArgs) Handles rdbSyracuse.CheckedChanged
        lblDisplay.Text = "Location: 

                           City:  Syracuse
                           State: New York"
    End Sub

    Private Sub rdbYale_CheckedChanged(sender As Object, e As EventArgs) Handles rdbYale.CheckedChanged
        lblDisplay.Text = "Location:
       
                           City:  New Haven
                           State: Connecticut"
    End Sub

    Private Sub rdbMichigan_CheckedChanged(sender As Object, e As EventArgs) Handles rdbMichigan.CheckedChanged
        lblDisplay.Text = "Location: 

                           City:  East Lansing
                           State: Michigan"
    End Sub

    Private Sub lblState_Click(sender As Object, e As EventArgs)

    End Sub
End Class