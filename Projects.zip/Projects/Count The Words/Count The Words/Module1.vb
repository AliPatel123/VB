﻿Module Module1

    Sub Main()
        Dim strSentence = Console.ReadLine
        Dim counter = 1
        For Each spaces In strSentence
            If (String.IsNullOrWhiteSpace(spaces)) Then
                counter += 1
            End If
        Next
        Console.WriteLine(counter)
        Console.ReadLine()
    End Sub

End Module
