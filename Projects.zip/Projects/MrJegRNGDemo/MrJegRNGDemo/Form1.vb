﻿Public Class Form1
    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        Dim intGuess As Integer
        intGuess = Rnd() * 10
        txtRandom.Text = intGuess
        MsgBox("The Guess is " & intGuess)
    End Sub
End Class
