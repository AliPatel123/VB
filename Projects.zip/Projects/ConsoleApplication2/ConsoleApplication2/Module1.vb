﻿Module Module1
    Sub Main()
        'Dim lo As Integer = Console.ReadLine
        'Dim hi As Integer = Console.ReadLine
        'Dim result As Integer
        'Dim i As Integer
        'Dim temp As Integer
        'For i = lo To hi
        'temp = i ^ 2
        'result += temp
        'Next
        'Console.WriteLine(result)
        Dim input As String = Console.ReadLine()
        Dim counthappy As Integer = 0
        Dim countsad As Integer = 0
        Dim i As Integer
        For i = 0 To input.Length - 3
            If (input(i) = ":" And input(i + 1) = "-" And input(i + 2) = ")") Then
                countsad += 1
            End If
            If (input(i) = ":" And input(i + 1) = "-" And input(i + 2) = "(") Then
                counthappy += 1
            End If
        Next
        If countsad > counthappy Then
            Console.WriteLine("happy")
        ElseIf countsad < counthappy Then
            Console.WriteLine("sad")
        ElseIf countsad = counthappy And counthappy = 0 And countsad = 0 Then
            Console.WriteLine("none")
        ElseIf countsad = counthappy Then
            Console.WriteLine("unsure")
            End If
        End Sub
End Module
