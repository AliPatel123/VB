﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSize = New System.Windows.Forms.GroupBox()
        Me.rdbXLarge = New System.Windows.Forms.RadioButton()
        Me.rdbMedium = New System.Windows.Forms.RadioButton()
        Me.rdbLarge = New System.Windows.Forms.RadioButton()
        Me.rdbSmall = New System.Windows.Forms.RadioButton()
        Me.grpSelectToppings = New System.Windows.Forms.GroupBox()
        Me.chkBlackOlives = New System.Windows.Forms.CheckBox()
        Me.chkPineapple = New System.Windows.Forms.CheckBox()
        Me.chkHam = New System.Windows.Forms.CheckBox()
        Me.chkGroundBeef = New System.Windows.Forms.CheckBox()
        Me.chkMushrooms = New System.Windows.Forms.CheckBox()
        Me.chkGreenPeppers = New System.Windows.Forms.CheckBox()
        Me.chkExtraCheese = New System.Windows.Forms.CheckBox()
        Me.chkPepperoni = New System.Windows.Forms.CheckBox()
        Me.chkBacon = New System.Windows.Forms.CheckBox()
        Me.chkItalianSausage = New System.Windows.Forms.CheckBox()
        Me.chkOnions = New System.Windows.Forms.CheckBox()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.grpSpecialtyPizza = New System.Windows.Forms.GroupBox()
        Me.rdbVegetarian = New System.Windows.Forms.RadioButton()
        Me.rdbHawaiian = New System.Windows.Forms.RadioButton()
        Me.rdbMeatlover = New System.Windows.Forms.RadioButton()
        Me.rdbDeluxe = New System.Windows.Forms.RadioButton()
        Me.btnOrder = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnEnd = New System.Windows.Forms.Button()
        Me.lblBigDisplay = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblHst = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.grpSize.SuspendLayout()
        Me.grpSelectToppings.SuspendLayout()
        Me.grpSpecialtyPizza.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSize
        '
        Me.grpSize.Controls.Add(Me.rdbXLarge)
        Me.grpSize.Controls.Add(Me.rdbMedium)
        Me.grpSize.Controls.Add(Me.rdbLarge)
        Me.grpSize.Controls.Add(Me.rdbSmall)
        Me.grpSize.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSize.ForeColor = System.Drawing.Color.Blue
        Me.grpSize.Location = New System.Drawing.Point(0, 0)
        Me.grpSize.Name = "grpSize"
        Me.grpSize.Size = New System.Drawing.Size(148, 175)
        Me.grpSize.TabIndex = 0
        Me.grpSize.TabStop = False
        Me.grpSize.Text = "Pizza Size:"
        '
        'rdbXLarge
        '
        Me.rdbXLarge.AutoSize = True
        Me.rdbXLarge.ForeColor = System.Drawing.Color.Black
        Me.rdbXLarge.Location = New System.Drawing.Point(6, 135)
        Me.rdbXLarge.Name = "rdbXLarge"
        Me.rdbXLarge.Size = New System.Drawing.Size(103, 28)
        Me.rdbXLarge.TabIndex = 3
        Me.rdbXLarge.TabStop = True
        Me.rdbXLarge.Text = "X-Large"
        Me.rdbXLarge.UseVisualStyleBackColor = True
        '
        'rdbMedium
        '
        Me.rdbMedium.AutoSize = True
        Me.rdbMedium.ForeColor = System.Drawing.Color.Black
        Me.rdbMedium.Location = New System.Drawing.Point(6, 65)
        Me.rdbMedium.Name = "rdbMedium"
        Me.rdbMedium.Size = New System.Drawing.Size(103, 28)
        Me.rdbMedium.TabIndex = 2
        Me.rdbMedium.TabStop = True
        Me.rdbMedium.Text = "Medium"
        Me.rdbMedium.UseVisualStyleBackColor = True
        '
        'rdbLarge
        '
        Me.rdbLarge.AutoSize = True
        Me.rdbLarge.ForeColor = System.Drawing.Color.Black
        Me.rdbLarge.Location = New System.Drawing.Point(6, 100)
        Me.rdbLarge.Name = "rdbLarge"
        Me.rdbLarge.Size = New System.Drawing.Size(81, 28)
        Me.rdbLarge.TabIndex = 1
        Me.rdbLarge.TabStop = True
        Me.rdbLarge.Text = "Large"
        Me.rdbLarge.UseVisualStyleBackColor = True
        '
        'rdbSmall
        '
        Me.rdbSmall.AutoSize = True
        Me.rdbSmall.ForeColor = System.Drawing.Color.Black
        Me.rdbSmall.Location = New System.Drawing.Point(6, 30)
        Me.rdbSmall.Name = "rdbSmall"
        Me.rdbSmall.Size = New System.Drawing.Size(79, 28)
        Me.rdbSmall.TabIndex = 0
        Me.rdbSmall.TabStop = True
        Me.rdbSmall.Text = "Small"
        Me.rdbSmall.UseVisualStyleBackColor = True
        '
        'grpSelectToppings
        '
        Me.grpSelectToppings.Controls.Add(Me.chkBlackOlives)
        Me.grpSelectToppings.Controls.Add(Me.chkPineapple)
        Me.grpSelectToppings.Controls.Add(Me.chkHam)
        Me.grpSelectToppings.Controls.Add(Me.chkGroundBeef)
        Me.grpSelectToppings.Controls.Add(Me.chkMushrooms)
        Me.grpSelectToppings.Controls.Add(Me.chkGreenPeppers)
        Me.grpSelectToppings.Controls.Add(Me.chkExtraCheese)
        Me.grpSelectToppings.Controls.Add(Me.chkPepperoni)
        Me.grpSelectToppings.Controls.Add(Me.chkBacon)
        Me.grpSelectToppings.Controls.Add(Me.chkItalianSausage)
        Me.grpSelectToppings.Controls.Add(Me.chkOnions)
        Me.grpSelectToppings.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSelectToppings.ForeColor = System.Drawing.Color.Blue
        Me.grpSelectToppings.Location = New System.Drawing.Point(154, 0)
        Me.grpSelectToppings.Name = "grpSelectToppings"
        Me.grpSelectToppings.Size = New System.Drawing.Size(515, 203)
        Me.grpSelectToppings.TabIndex = 1
        Me.grpSelectToppings.TabStop = False
        Me.grpSelectToppings.Text = "Select Toppings:"
        '
        'chkBlackOlives
        '
        Me.chkBlackOlives.AutoSize = True
        Me.chkBlackOlives.ForeColor = System.Drawing.Color.Black
        Me.chkBlackOlives.Location = New System.Drawing.Point(188, 129)
        Me.chkBlackOlives.Name = "chkBlackOlives"
        Me.chkBlackOlives.Size = New System.Drawing.Size(143, 28)
        Me.chkBlackOlives.TabIndex = 12
        Me.chkBlackOlives.Text = "Black Olives"
        Me.chkBlackOlives.UseVisualStyleBackColor = True
        '
        'chkPineapple
        '
        Me.chkPineapple.AutoSize = True
        Me.chkPineapple.ForeColor = System.Drawing.Color.Black
        Me.chkPineapple.Location = New System.Drawing.Point(188, 164)
        Me.chkPineapple.Name = "chkPineapple"
        Me.chkPineapple.Size = New System.Drawing.Size(123, 28)
        Me.chkPineapple.TabIndex = 13
        Me.chkPineapple.Text = "Pineapple"
        Me.chkPineapple.UseVisualStyleBackColor = True
        '
        'chkHam
        '
        Me.chkHam.AutoSize = True
        Me.chkHam.ForeColor = System.Drawing.Color.Black
        Me.chkHam.Location = New System.Drawing.Point(19, 94)
        Me.chkHam.Name = "chkHam"
        Me.chkHam.Size = New System.Drawing.Size(72, 28)
        Me.chkHam.TabIndex = 6
        Me.chkHam.Text = "Ham"
        Me.chkHam.UseVisualStyleBackColor = True
        '
        'chkGroundBeef
        '
        Me.chkGroundBeef.AutoSize = True
        Me.chkGroundBeef.ForeColor = System.Drawing.Color.Black
        Me.chkGroundBeef.Location = New System.Drawing.Point(19, 164)
        Me.chkGroundBeef.Name = "chkGroundBeef"
        Me.chkGroundBeef.Size = New System.Drawing.Size(147, 28)
        Me.chkGroundBeef.TabIndex = 8
        Me.chkGroundBeef.Text = "Ground Beef"
        Me.chkGroundBeef.UseVisualStyleBackColor = True
        '
        'chkMushrooms
        '
        Me.chkMushrooms.AutoSize = True
        Me.chkMushrooms.ForeColor = System.Drawing.Color.Black
        Me.chkMushrooms.Location = New System.Drawing.Point(188, 24)
        Me.chkMushrooms.Name = "chkMushrooms"
        Me.chkMushrooms.Size = New System.Drawing.Size(138, 28)
        Me.chkMushrooms.TabIndex = 9
        Me.chkMushrooms.Text = "Mushrooms"
        Me.chkMushrooms.UseVisualStyleBackColor = True
        '
        'chkGreenPeppers
        '
        Me.chkGreenPeppers.AutoSize = True
        Me.chkGreenPeppers.ForeColor = System.Drawing.Color.Black
        Me.chkGreenPeppers.Location = New System.Drawing.Point(188, 59)
        Me.chkGreenPeppers.Name = "chkGreenPeppers"
        Me.chkGreenPeppers.Size = New System.Drawing.Size(171, 28)
        Me.chkGreenPeppers.TabIndex = 10
        Me.chkGreenPeppers.Text = "Green Peppers"
        Me.chkGreenPeppers.UseVisualStyleBackColor = True
        '
        'chkExtraCheese
        '
        Me.chkExtraCheese.AutoSize = True
        Me.chkExtraCheese.ForeColor = System.Drawing.Color.Black
        Me.chkExtraCheese.Location = New System.Drawing.Point(352, 24)
        Me.chkExtraCheese.Name = "chkExtraCheese"
        Me.chkExtraCheese.Size = New System.Drawing.Size(155, 28)
        Me.chkExtraCheese.TabIndex = 14
        Me.chkExtraCheese.Text = "Extra Cheese"
        Me.chkExtraCheese.UseVisualStyleBackColor = True
        '
        'chkPepperoni
        '
        Me.chkPepperoni.AutoSize = True
        Me.chkPepperoni.ForeColor = System.Drawing.Color.Black
        Me.chkPepperoni.Location = New System.Drawing.Point(19, 24)
        Me.chkPepperoni.Name = "chkPepperoni"
        Me.chkPepperoni.Size = New System.Drawing.Size(126, 28)
        Me.chkPepperoni.TabIndex = 4
        Me.chkPepperoni.Text = "Pepperoni"
        Me.chkPepperoni.UseVisualStyleBackColor = True
        '
        'chkBacon
        '
        Me.chkBacon.AutoSize = True
        Me.chkBacon.ForeColor = System.Drawing.Color.Black
        Me.chkBacon.Location = New System.Drawing.Point(19, 59)
        Me.chkBacon.Name = "chkBacon"
        Me.chkBacon.Size = New System.Drawing.Size(88, 28)
        Me.chkBacon.TabIndex = 5
        Me.chkBacon.Text = "Bacon"
        Me.chkBacon.UseVisualStyleBackColor = True
        '
        'chkItalianSausage
        '
        Me.chkItalianSausage.AutoSize = True
        Me.chkItalianSausage.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkItalianSausage.ForeColor = System.Drawing.Color.Black
        Me.chkItalianSausage.Location = New System.Drawing.Point(19, 129)
        Me.chkItalianSausage.Name = "chkItalianSausage"
        Me.chkItalianSausage.Size = New System.Drawing.Size(170, 28)
        Me.chkItalianSausage.TabIndex = 7
        Me.chkItalianSausage.Text = "Italian Sausage"
        Me.chkItalianSausage.UseVisualStyleBackColor = True
        '
        'chkOnions
        '
        Me.chkOnions.AutoSize = True
        Me.chkOnions.ForeColor = System.Drawing.Color.Black
        Me.chkOnions.Location = New System.Drawing.Point(188, 94)
        Me.chkOnions.Name = "chkOnions"
        Me.chkOnions.Size = New System.Drawing.Size(96, 28)
        Me.chkOnions.TabIndex = 11
        Me.chkOnions.Text = "Onions"
        Me.chkOnions.UseVisualStyleBackColor = True
        '
        'lblQuantity
        '
        Me.lblQuantity.AutoSize = True
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.Location = New System.Drawing.Point(1, 178)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(92, 24)
        Me.lblQuantity.TabIndex = 2
        Me.lblQuantity.Text = "Quantity:"
        '
        'txtQuantity
        '
        Me.txtQuantity.Location = New System.Drawing.Point(114, 183)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(34, 20)
        Me.txtQuantity.TabIndex = 3
        '
        'grpSpecialtyPizza
        '
        Me.grpSpecialtyPizza.Controls.Add(Me.rdbVegetarian)
        Me.grpSpecialtyPizza.Controls.Add(Me.rdbHawaiian)
        Me.grpSpecialtyPizza.Controls.Add(Me.rdbMeatlover)
        Me.grpSpecialtyPizza.Controls.Add(Me.rdbDeluxe)
        Me.grpSpecialtyPizza.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpSpecialtyPizza.ForeColor = System.Drawing.Color.Blue
        Me.grpSpecialtyPizza.Location = New System.Drawing.Point(173, 209)
        Me.grpSpecialtyPizza.Name = "grpSpecialtyPizza"
        Me.grpSpecialtyPizza.Size = New System.Drawing.Size(496, 100)
        Me.grpSpecialtyPizza.TabIndex = 15
        Me.grpSpecialtyPizza.TabStop = False
        Me.grpSpecialtyPizza.Text = "Specialty Pizza"
        '
        'rdbVegetarian
        '
        Me.rdbVegetarian.AutoSize = True
        Me.rdbVegetarian.ForeColor = System.Drawing.Color.Black
        Me.rdbVegetarian.Location = New System.Drawing.Point(294, 62)
        Me.rdbVegetarian.Name = "rdbVegetarian"
        Me.rdbVegetarian.Size = New System.Drawing.Size(129, 28)
        Me.rdbVegetarian.TabIndex = 19
        Me.rdbVegetarian.TabStop = True
        Me.rdbVegetarian.Text = "Vegetarian"
        Me.rdbVegetarian.UseVisualStyleBackColor = True
        '
        'rdbHawaiian
        '
        Me.rdbHawaiian.AutoSize = True
        Me.rdbHawaiian.ForeColor = System.Drawing.Color.Black
        Me.rdbHawaiian.Location = New System.Drawing.Point(14, 62)
        Me.rdbHawaiian.Name = "rdbHawaiian"
        Me.rdbHawaiian.Size = New System.Drawing.Size(113, 28)
        Me.rdbHawaiian.TabIndex = 18
        Me.rdbHawaiian.TabStop = True
        Me.rdbHawaiian.Text = "Hawaiian"
        Me.rdbHawaiian.UseVisualStyleBackColor = True
        '
        'rdbMeatlover
        '
        Me.rdbMeatlover.AutoSize = True
        Me.rdbMeatlover.ForeColor = System.Drawing.Color.Black
        Me.rdbMeatlover.Location = New System.Drawing.Point(294, 28)
        Me.rdbMeatlover.Name = "rdbMeatlover"
        Me.rdbMeatlover.Size = New System.Drawing.Size(119, 28)
        Me.rdbMeatlover.TabIndex = 17
        Me.rdbMeatlover.TabStop = True
        Me.rdbMeatlover.Text = "Meatlover"
        Me.rdbMeatlover.UseVisualStyleBackColor = True
        '
        'rdbDeluxe
        '
        Me.rdbDeluxe.AutoSize = True
        Me.rdbDeluxe.ForeColor = System.Drawing.Color.Black
        Me.rdbDeluxe.Location = New System.Drawing.Point(14, 28)
        Me.rdbDeluxe.Name = "rdbDeluxe"
        Me.rdbDeluxe.Size = New System.Drawing.Size(94, 28)
        Me.rdbDeluxe.TabIndex = 16
        Me.rdbDeluxe.TabStop = True
        Me.rdbDeluxe.Text = "Deluxe"
        Me.rdbDeluxe.UseVisualStyleBackColor = True
        '
        'btnOrder
        '
        Me.btnOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOrder.Location = New System.Drawing.Point(177, 338)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(166, 35)
        Me.btnOrder.TabIndex = 20
        Me.btnOrder.Text = "Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(342, 338)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(164, 35)
        Me.btnClear.TabIndex = 21
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnEnd
        '
        Me.btnEnd.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnd.Location = New System.Drawing.Point(506, 338)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(166, 35)
        Me.btnEnd.TabIndex = 22
        Me.btnEnd.Text = "End"
        Me.btnEnd.UseVisualStyleBackColor = True
        '
        'lblBigDisplay
        '
        Me.lblBigDisplay.BackColor = System.Drawing.Color.Beige
        Me.lblBigDisplay.ForeColor = System.Drawing.Color.Black
        Me.lblBigDisplay.Location = New System.Drawing.Point(5, 217)
        Me.lblBigDisplay.Name = "lblBigDisplay"
        Me.lblBigDisplay.Size = New System.Drawing.Size(162, 156)
        Me.lblBigDisplay.TabIndex = 23
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.BackColor = System.Drawing.Color.Beige
        Me.lblPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice.Location = New System.Drawing.Point(12, 226)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(64, 24)
        Me.lblPrice.TabIndex = 24
        Me.lblPrice.Text = "Price:"
        '
        'lblHst
        '
        Me.lblHst.AutoSize = True
        Me.lblHst.BackColor = System.Drawing.Color.Beige
        Me.lblHst.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHst.Location = New System.Drawing.Point(12, 285)
        Me.lblHst.Name = "lblHst"
        Me.lblHst.Size = New System.Drawing.Size(57, 24)
        Me.lblHst.TabIndex = 25
        Me.lblHst.Text = "HST:"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BackColor = System.Drawing.Color.Beige
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(12, 338)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(62, 24)
        Me.lblTotal.TabIndex = 26
        Me.lblTotal.Text = "Total:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(681, 396)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblHst)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblBigDisplay)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.grpSpecialtyPizza)
        Me.Controls.Add(Me.txtQuantity)
        Me.Controls.Add(Me.lblQuantity)
        Me.Controls.Add(Me.grpSelectToppings)
        Me.Controls.Add(Me.grpSize)
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Name = "Form1"
        Me.RightToLeftLayout = True
        Me.Text = "Pizza Palace Order Form"
        Me.grpSize.ResumeLayout(False)
        Me.grpSize.PerformLayout()
        Me.grpSelectToppings.ResumeLayout(False)
        Me.grpSelectToppings.PerformLayout()
        Me.grpSpecialtyPizza.ResumeLayout(False)
        Me.grpSpecialtyPizza.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpSize As GroupBox
    Friend WithEvents rdbXLarge As RadioButton
    Friend WithEvents rdbMedium As RadioButton
    Friend WithEvents rdbLarge As RadioButton
    Friend WithEvents rdbSmall As RadioButton
    Friend WithEvents grpSelectToppings As GroupBox
    Friend WithEvents lblQuantity As Label
    Friend WithEvents txtQuantity As TextBox
    Friend WithEvents chkBlackOlives As CheckBox
    Friend WithEvents chkPineapple As CheckBox
    Friend WithEvents chkHam As CheckBox
    Friend WithEvents chkGroundBeef As CheckBox
    Friend WithEvents chkMushrooms As CheckBox
    Friend WithEvents chkGreenPeppers As CheckBox
    Friend WithEvents chkExtraCheese As CheckBox
    Friend WithEvents chkPepperoni As CheckBox
    Friend WithEvents chkBacon As CheckBox
    Friend WithEvents chkItalianSausage As CheckBox
    Friend WithEvents chkOnions As CheckBox
    Friend WithEvents grpSpecialtyPizza As GroupBox
    Friend WithEvents rdbVegetarian As RadioButton
    Friend WithEvents rdbHawaiian As RadioButton
    Friend WithEvents rdbMeatlover As RadioButton
    Friend WithEvents rdbDeluxe As RadioButton
    Friend WithEvents btnOrder As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnEnd As Button
    Friend WithEvents lblBigDisplay As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblHst As Label
    Friend WithEvents lblTotal As Label
End Class
