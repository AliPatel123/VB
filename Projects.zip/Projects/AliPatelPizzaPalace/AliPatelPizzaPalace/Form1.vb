﻿Public Class Form1
    Const Small As Decimal = 7.0 'Declaring the constant small
    Const Medium As Decimal = 10.0 'Declaring the constant medium
    Const Large As Decimal = 12.0 'Declaring the constant large
    Const XLarge As Decimal = 15.0 'Declaring the constant extra large
    Dim dblPrice As Double 'Declaring the price as a double variable
    Dim Quantity As Integer 'Declaring the quantity as an integer variable
    Private Sub rdbMeatlover_CheckedChanged(sender As Object, e As EventArgs) Handles rdbMeatlover.CheckedChanged
        chkBacon.Checked = True 'Changing the check status if meatlover is checked to true
        chkBlackOlives.Checked = False 'Changing the check status if meatlover is checked to false
        chkExtraCheese.Checked = False 'Changing the check status if meatlover is checked to false
        chkGreenPeppers.Checked = False 'Changing the check status if meatlover is checked to false
        chkGroundBeef.Checked = False 'Changing the check status if meatlover is checked to false
        chkHam.Checked = True 'Changing the check status if meatlover is checked to true
        chkItalianSausage.Checked = True 'Changing the check status if meatlover is checked to true
        chkMushrooms.Checked = False 'Changing the check status if meatlover is checked to false
        chkOnions.Checked = False 'Changing the check status if meatlover is checked to false
        chkPepperoni.Checked = False 'Changing the check status if meatlover is checked to false
        chkPineapple.Checked = False 'Changing the check status if meatlover is checked to false
    End Sub
    Private Sub rdbDeluxe_CheckedChanged(sender As Object, e As EventArgs) Handles rdbDeluxe.CheckedChanged
        chkBacon.Checked = False 'Changing the check status if deluxe is checked to false
        chkBlackOlives.Checked = False 'Changing the check status if deluxe is checked to false
        chkExtraCheese.Checked = False 'Changing the check status if deluxe is checked to false
        chkGreenPeppers.Checked = True 'Changing the check status if deluxe is checked to true
        chkGroundBeef.Checked = False 'Changing the check status if deluxe is checked to false
        chkHam.Checked = False 'Changing the check status if deluxe is checked to false
        chkItalianSausage.Checked = False 'Changing the check status if deluxe is checked to false
        chkMushrooms.Checked = True 'Changing the check status if deluxe is checked to true
        chkOnions.Checked = False 'Changing the check status if deluxe is checked to false
        chkPepperoni.Checked = True 'Changing the check status if deluxe is checked to true
        chkPineapple.Checked = False 'Changing the check status if deluxe is checked to false
    End Sub
    Private Sub rdbVegetarian_CheckedChanged(sender As Object, e As EventArgs) Handles rdbVegetarian.CheckedChanged
        chkBacon.Checked = False 'Changing the check status if vegetarian is checked to false
        chkBlackOlives.Checked = False 'Changing the check status if vegetarian is checked to false
        chkExtraCheese.Checked = False 'Changing the check status if vegetarian is checked to false
        chkGreenPeppers.Checked = True 'Changing the check status if vegetarian is checked to true
        chkGroundBeef.Checked = False 'Changing the check status if vegetarian is checked to false
        chkHam.Checked = False 'Changing the check status if vegetarian is checked to false
        chkItalianSausage.Checked = False 'Changing the check status if vegetarian is checked to false
        chkMushrooms.Checked = True 'Changing the check status if vegetarian is checked to true
        chkOnions.Checked = True 'Changing the check status if vegetarian is checked to true
        chkPepperoni.Checked = False 'Changing the check status if vegetarian is checked to false
        chkPineapple.Checked = False 'Changing the check status if vegetarian is checked to false
    End Sub
    Private Sub rdbHawaiian_CheckedChanged(sender As Object, e As EventArgs) Handles rdbHawaiian.CheckedChanged
        chkBacon.Checked = False 'Changing the check status if hawaiian is checked to false
        chkBlackOlives.Checked = False 'Changing the check status if hawaiian is checked to false
        chkExtraCheese.Checked = True 'Changing the check status if hawaiian is checked to true
        chkGreenPeppers.Checked = False 'Changing the check status if hawaiian is checked to false
        chkGroundBeef.Checked = False 'Changing the check status if hawaiian is checked to false
        chkHam.Checked = True 'Changing the check status if hawaiian is checked to true
        chkItalianSausage.Checked = False 'Changing the check status if hawaiian is checked to false
        chkMushrooms.Checked = False 'Changing the check status if hawaiian is checked to false
        chkOnions.Checked = False 'Changing the check status if hawaiian is checked to false
        chkPepperoni.Checked = False 'Changing the check status if hawaiian is checked to false
        chkPineapple.Checked = True 'Changing the check status if hawaiian is checked to true
    End Sub
    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click
        If rdbSmall.Checked = True Then
            dblPrice = 7 'Setting the base price to 7 is the size is small
        ElseIf rdbMedium.Checked = True Then
            dblPrice = 10 'Setting the base price to 10 is the size is medium
        ElseIf rdbLarge.Checked = True Then
            dblPrice = 12 'Setting the base price to 12 is the size is large
        ElseIf rdbXLarge.Checked = True Then
            dblPrice = 15 'Setting the base price to 15 is the size is extra large
        End If
        If chkBacon.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkBlackOlives.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkExtraCheese.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkGreenPeppers.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkGroundBeef.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkHam.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkItalianSausage.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkMushrooms.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkOnions.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkPepperoni.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If chkPineapple.Checked = True Then
            dblPrice += 0.5 'Adding the $0.50 cost of extra toppings to the price
        End If
        If txtQuantity.Text < 1 Or txtQuantity.Text > 10 Then
            MsgBox("Enter a quantity between 1 and 10!") 'Providing an error message if the user enters an unacceptable quantity
        End If
        Quantity = txtQuantity.Text 'Assigning quantity to the text box "txtQuantity"
        dblPrice *= Quantity 'Multiplying the price by the quantity
        lblPrice.Text = "Price: $" & dblPrice 'Displaying price
        lblHst.Text = "HST: $" & (dblPrice * 0.13) 'Displaying HST
        lblTotal.Text = "Total: $" & (dblPrice * 1.13) 'Displaying total cost
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        rdbDeluxe.Checked = False 'Clearing the specialty pizza radio button when the clear button is pressed
        rdbHawaiian.Checked = False 'Clearing the specialty pizza radio button when the clear button is pressed
        rdbVegetarian.Checked = False 'Clearing the specialty pizza radio button when the clear button is pressed
        rdbMeatlover.Checked = False 'Clearing the specialty pizza radio button when the clear button is pressed
        chkBacon.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkBlackOlives.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkExtraCheese.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkGreenPeppers.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkGroundBeef.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkHam.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkItalianSausage.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkMushrooms.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkOnions.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkPepperoni.Checked = False 'Clearing the topping check box when the clear button is pressed
        chkPineapple.Checked = False 'Clearing the topping check box when the clear button is pressed
        lblPrice.Text = "" 'Clearing the price label
        lblTotal.Text = "" 'Clearing the total price label
        lblHst.Text = "" 'Clearing the hst label
        txtQuantity.Text = "" 'Clearing the quantity text box
    End Sub
    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        Me.Close() 'Closing the program when the end button is pressed
    End Sub
End Class
