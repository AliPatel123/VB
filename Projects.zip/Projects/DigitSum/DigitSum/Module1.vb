﻿Module Module1

    Sub Main()
        Dim inta As Integer
        inta = Console.ReadLine()
        Dim intsum As Integer = 0
        Do While (inta > 0)
            intsum = intsum + inta Mod 10
            inta = inta \ 10
        Loop
        Console.WriteLine(intsum)
        Console.ReadLine()
    End Sub

End Module
