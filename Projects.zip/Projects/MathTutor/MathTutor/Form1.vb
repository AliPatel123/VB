﻿Public Class Form1
    Dim intnum1 As Integer
    Dim intnum2 As Integer
    Dim intSign As Integer
    Dim strSign As String = ""
    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        intnum1 = Rnd() * (10 - 1)
        intnum2 = Rnd() * (10 - 1)
        intSign = Rnd() * (4 - 0)
        If intSign = 1 Then
            strSign = "+"
        ElseIf intSign = 2 Then
            strSign = "-"
        ElseIf intSign = 3 Then
            strSign = "*"
        ElseIf intSign = 4 Then
            strSign = "/"

        End If
        txtNum1.Text = intnum1
        txtNum2.Text = intnum2
        lblSign.Text = strSign
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim intUser As Integer = txtUser.Text

        If strSign = "+" Then
            If (intnum1 + intnum2 = intUser) Then
                txtDisplay.Text = "Correct"
            Else
                txtDisplay.Text = "Incorrect"
            End If
        ElseIf strSign = "-" Then
            If (intnum1 - intnum2 = intUser) Then
                txtDisplay.Text = "Correct"
            Else
                txtDisplay.Text = "Incorrect"
            End If

        ElseIf strSign = "*" Then
            If (intnum1 * intnum2 = intUser) Then
                txtDisplay.Text = "Correct"
            Else
                txtDisplay.Text = "Incorrect"
            End If

        ElseIf strSign = "/" Then
            If (intnum1 / intnum2 = intUser) Then
                txtDisplay.Text = "Correct"
            Else
                txtDisplay.Text = "Incorrect"
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If strSign = "+" Then
            txtDisplay.Text = intnum1 + intnum2
        ElseIf strSign = "-" Then
            txtDisplay.Text = intnum1 - intnum2
        ElseIf strSign = "*" Then
            txtDisplay.Text = intnum1 * intnum2
        ElseIf strSign = "/" Then
            txtDisplay.Text = intnum1 / intnum2

        End If
    End Sub
End Class
