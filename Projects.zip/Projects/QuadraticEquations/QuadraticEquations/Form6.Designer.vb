﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.picSolving = New System.Windows.Forms.PictureBox()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnNext1 = New System.Windows.Forms.Button()
        Me.lblcompsqr = New System.Windows.Forms.Label()
        Me.lblLesson = New System.Windows.Forms.Label()
        CType(Me.picSolving, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picSolving
        '
        Me.picSolving.BackgroundImage = CType(resources.GetObject("picSolving.BackgroundImage"), System.Drawing.Image)
        Me.picSolving.Image = CType(resources.GetObject("picSolving.Image"), System.Drawing.Image)
        Me.picSolving.Location = New System.Drawing.Point(47, 173)
        Me.picSolving.Name = "picSolving"
        Me.picSolving.Size = New System.Drawing.Size(773, 414)
        Me.picSolving.TabIndex = 29
        Me.picSolving.TabStop = False
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(920, 328)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(166, 49)
        Me.btnPrevious.TabIndex = 28
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(920, 383)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(166, 49)
        Me.btnHome.TabIndex = 27
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnNext1
        '
        Me.btnNext1.Location = New System.Drawing.Point(920, 273)
        Me.btnNext1.Name = "btnNext1"
        Me.btnNext1.Size = New System.Drawing.Size(166, 49)
        Me.btnNext1.TabIndex = 26
        Me.btnNext1.Text = "Next"
        Me.btnNext1.UseVisualStyleBackColor = True
        '
        'lblcompsqr
        '
        Me.lblcompsqr.AutoSize = True
        Me.lblcompsqr.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcompsqr.Location = New System.Drawing.Point(79, 101)
        Me.lblcompsqr.Name = "lblcompsqr"
        Me.lblcompsqr.Size = New System.Drawing.Size(249, 25)
        Me.lblcompsqr.TabIndex = 25
        Me.lblcompsqr.Text = "Completing the square"
        '
        'lblLesson
        '
        Me.lblLesson.AutoSize = True
        Me.lblLesson.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLesson.Location = New System.Drawing.Point(457, 21)
        Me.lblLesson.Name = "lblLesson"
        Me.lblLesson.Size = New System.Drawing.Size(246, 73)
        Me.lblLesson.TabIndex = 24
        Me.lblLesson.Text = "Lesson"
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1165, 645)
        Me.Controls.Add(Me.picSolving)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnNext1)
        Me.Controls.Add(Me.lblcompsqr)
        Me.Controls.Add(Me.lblLesson)
        Me.Name = "Form6"
        Me.Text = "Lesson"
        CType(Me.picSolving, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picSolving As PictureBox
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents btnNext1 As Button
    Friend WithEvents lblcompsqr As Label
    Friend WithEvents lblLesson As Label
End Class
