﻿Public Class Form1
    Private Sub btnLesson_Click(sender As Object, e As EventArgs) Handles btnLesson.Click
        Form2.Show() 'Showing the lesson
    End Sub
    Private Sub btnInstructions_Click(sender As Object, e As EventArgs) Handles btnInstructions.Click
        MsgBox("Click on Lesson to start the lesson.
Click on Practice to get some practice questions.
Click on Test for a final test.
Credits go to the McGraw-Hill Ryerson Principal of Mathematics 10 textbook, mathisfun.com and me.") 'Displaying a message on how to use my program
    End Sub

    Private Sub btnPractice_Click(sender As Object, e As EventArgs) Handles btnPractice.Click
        Form11.Show()
    End Sub

    Private Sub btnTest_Click(sender As Object, e As EventArgs) Handles btnTest.Click
        Form12.Show
    End Sub
End Class
