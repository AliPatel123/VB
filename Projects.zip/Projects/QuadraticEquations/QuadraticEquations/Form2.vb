﻿Public Class Form2
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Me.Close() 'Closing the form
    End Sub

    Private Sub btnNext1_Click(sender As Object, e As EventArgs) Handles btnNext1.Click
        Form3.Show() 'Showing the next form then closing this one
        Me.Close
    End Sub
End Class