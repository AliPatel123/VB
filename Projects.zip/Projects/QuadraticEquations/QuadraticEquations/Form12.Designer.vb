﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form12
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form12))
        Me.lbltitle = New System.Windows.Forms.Label()
        Me.lblq1 = New System.Windows.Forms.Label()
        Me.txtq1 = New System.Windows.Forms.TextBox()
        Me.lblq2 = New System.Windows.Forms.Label()
        Me.lblq3 = New System.Windows.Forms.Label()
        Me.txtq2 = New System.Windows.Forms.TextBox()
        Me.txtq3 = New System.Windows.Forms.TextBox()
        Me.txtq4 = New System.Windows.Forms.TextBox()
        Me.lblq4 = New System.Windows.Forms.Label()
        Me.lblq5 = New System.Windows.Forms.Label()
        Me.txtq5 = New System.Windows.Forms.TextBox()
        Me.lblq6 = New System.Windows.Forms.Label()
        Me.lblq7 = New System.Windows.Forms.Label()
        Me.lblq8 = New System.Windows.Forms.Label()
        Me.txtq6 = New System.Windows.Forms.TextBox()
        Me.txtq7 = New System.Windows.Forms.TextBox()
        Me.txtq8 = New System.Windows.Forms.TextBox()
        Me.lblq9 = New System.Windows.Forms.Label()
        Me.lblq10 = New System.Windows.Forms.Label()
        Me.txtq9 = New System.Windows.Forms.TextBox()
        Me.txtq10 = New System.Windows.Forms.TextBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbltitle
        '
        Me.lbltitle.AutoSize = True
        Me.lbltitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltitle.Location = New System.Drawing.Point(495, 9)
        Me.lbltitle.Name = "lbltitle"
        Me.lbltitle.Size = New System.Drawing.Size(161, 73)
        Me.lbltitle.TabIndex = 0
        Me.lbltitle.Text = "Test"
        '
        'lblq1
        '
        Me.lblq1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq1.Location = New System.Drawing.Point(12, 101)
        Me.lblq1.Name = "lblq1"
        Me.lblq1.Size = New System.Drawing.Size(487, 119)
        Me.lblq1.TabIndex = 1
        Me.lblq1.Text = "1. The path of a rock thrown in the air can be shown as h = -0.05d^2 + 0.3d + 0.8" &
    " where h is the height and d is the horizontal distance. From what height was th" &
    "e rock thrown?"
        '
        'txtq1
        '
        Me.txtq1.Location = New System.Drawing.Point(206, 223)
        Me.txtq1.Name = "txtq1"
        Me.txtq1.Size = New System.Drawing.Size(100, 20)
        Me.txtq1.TabIndex = 2
        '
        'lblq2
        '
        Me.lblq2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq2.Location = New System.Drawing.Point(13, 246)
        Me.lblq2.Name = "lblq2"
        Me.lblq2.Size = New System.Drawing.Size(320, 79)
        Me.lblq2.TabIndex = 3
        Me.lblq2.Text = "2. How far does the rock in question 1 travel horizontally before it hits the gro" &
    "und?"
        '
        'lblq3
        '
        Me.lblq3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq3.Location = New System.Drawing.Point(12, 351)
        Me.lblq3.Name = "lblq3"
        Me.lblq3.Size = New System.Drawing.Size(321, 85)
        Me.lblq3.TabIndex = 4
        Me.lblq3.Text = "3. What was the maximum height of the rock thrown in question 1?"
        '
        'txtq2
        '
        Me.txtq2.Location = New System.Drawing.Point(102, 328)
        Me.txtq2.Name = "txtq2"
        Me.txtq2.Size = New System.Drawing.Size(100, 20)
        Me.txtq2.TabIndex = 5
        '
        'txtq3
        '
        Me.txtq3.Location = New System.Drawing.Point(102, 439)
        Me.txtq3.Name = "txtq3"
        Me.txtq3.Size = New System.Drawing.Size(100, 20)
        Me.txtq3.TabIndex = 6
        '
        'txtq4
        '
        Me.txtq4.Location = New System.Drawing.Point(122, 570)
        Me.txtq4.Name = "txtq4"
        Me.txtq4.Size = New System.Drawing.Size(100, 20)
        Me.txtq4.TabIndex = 7
        '
        'lblq4
        '
        Me.lblq4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq4.Location = New System.Drawing.Point(12, 462)
        Me.lblq4.Name = "lblq4"
        Me.lblq4.Size = New System.Drawing.Size(348, 105)
        Me.lblq4.TabIndex = 8
        Me.lblq4.Text = "4. A cylinder has a height of 5 cm and surface area of 100 cm^2. What is the radi" &
    "us to the nearest tenth of a centimetre."
        '
        'lblq5
        '
        Me.lblq5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq5.Location = New System.Drawing.Point(503, 101)
        Me.lblq5.Name = "lblq5"
        Me.lblq5.Size = New System.Drawing.Size(289, 119)
        Me.lblq5.TabIndex = 9
        Me.lblq5.Text = "5. The diagonals of a kite measure 10 cm and 12 cm respectively. What is the area" &
    " of the kite?"
        '
        'txtq5
        '
        Me.txtq5.Location = New System.Drawing.Point(598, 223)
        Me.txtq5.Name = "txtq5"
        Me.txtq5.Size = New System.Drawing.Size(100, 20)
        Me.txtq5.TabIndex = 10
        '
        'lblq6
        '
        Me.lblq6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq6.Location = New System.Drawing.Point(449, 246)
        Me.lblq6.Name = "lblq6"
        Me.lblq6.Size = New System.Drawing.Size(343, 108)
        Me.lblq6.TabIndex = 11
        Me.lblq6.Text = "6. A system of linear equations goes as follows. a + b + c = 9, ab + bc + ac = 26" &
    " and abc = 24. What is the value of a?"
        '
        'lblq7
        '
        Me.lblq7.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq7.Location = New System.Drawing.Point(449, 380)
        Me.lblq7.Name = "lblq7"
        Me.lblq7.Size = New System.Drawing.Size(307, 84)
        Me.lblq7.TabIndex = 12
        Me.lblq7.Text = "7. With the same system of linear equations in question 6, what is the value of b" &
    "?"
        '
        'lblq8
        '
        Me.lblq8.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq8.Location = New System.Drawing.Point(449, 491)
        Me.lblq8.Name = "lblq8"
        Me.lblq8.Size = New System.Drawing.Size(307, 83)
        Me.lblq8.TabIndex = 13
        Me.lblq8.Text = "8. With the same system of linear equations in question 6, what is the value of c" &
    "?"
        '
        'txtq6
        '
        Me.txtq6.Location = New System.Drawing.Point(575, 357)
        Me.txtq6.Name = "txtq6"
        Me.txtq6.Size = New System.Drawing.Size(100, 20)
        Me.txtq6.TabIndex = 14
        '
        'txtq7
        '
        Me.txtq7.Location = New System.Drawing.Point(556, 468)
        Me.txtq7.Name = "txtq7"
        Me.txtq7.Size = New System.Drawing.Size(100, 20)
        Me.txtq7.TabIndex = 15
        '
        'txtq8
        '
        Me.txtq8.Location = New System.Drawing.Point(556, 577)
        Me.txtq8.Name = "txtq8"
        Me.txtq8.Size = New System.Drawing.Size(100, 20)
        Me.txtq8.TabIndex = 16
        '
        'lblq9
        '
        Me.lblq9.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq9.Location = New System.Drawing.Point(798, 101)
        Me.lblq9.Name = "lblq9"
        Me.lblq9.Size = New System.Drawing.Size(353, 152)
        Me.lblq9.TabIndex = 17
        Me.lblq9.Text = "9. 144 is a perfect square (12^2). The sum of the digits (1+4+4) is 9, which is a" &
    "lso a perfect square (3^2). How many other numbers have this property?"
        '
        'lblq10
        '
        Me.lblq10.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq10.Location = New System.Drawing.Point(797, 279)
        Me.lblq10.Name = "lblq10"
        Me.lblq10.Size = New System.Drawing.Size(354, 183)
        Me.lblq10.TabIndex = 18
        Me.lblq10.Text = resources.GetString("lblq10.Text")
        '
        'txtq9
        '
        Me.txtq9.Location = New System.Drawing.Point(922, 256)
        Me.txtq9.Name = "txtq9"
        Me.txtq9.Size = New System.Drawing.Size(100, 20)
        Me.txtq9.TabIndex = 19
        '
        'txtq10
        '
        Me.txtq10.Location = New System.Drawing.Point(922, 468)
        Me.txtq10.Name = "txtq10"
        Me.txtq10.Size = New System.Drawing.Size(100, 20)
        Me.txtq10.TabIndex = 20
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(934, 514)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 21
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(934, 575)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 22
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'Form12
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1163, 666)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.txtq10)
        Me.Controls.Add(Me.txtq9)
        Me.Controls.Add(Me.lblq10)
        Me.Controls.Add(Me.lblq9)
        Me.Controls.Add(Me.txtq8)
        Me.Controls.Add(Me.txtq7)
        Me.Controls.Add(Me.txtq6)
        Me.Controls.Add(Me.lblq8)
        Me.Controls.Add(Me.lblq7)
        Me.Controls.Add(Me.lblq6)
        Me.Controls.Add(Me.txtq5)
        Me.Controls.Add(Me.lblq5)
        Me.Controls.Add(Me.lblq4)
        Me.Controls.Add(Me.txtq4)
        Me.Controls.Add(Me.txtq3)
        Me.Controls.Add(Me.txtq2)
        Me.Controls.Add(Me.lblq3)
        Me.Controls.Add(Me.lblq2)
        Me.Controls.Add(Me.txtq1)
        Me.Controls.Add(Me.lblq1)
        Me.Controls.Add(Me.lbltitle)
        Me.Name = "Form12"
        Me.Text = "Test"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbltitle As Label
    Friend WithEvents lblq1 As Label
    Friend WithEvents txtq1 As TextBox
    Friend WithEvents lblq2 As Label
    Friend WithEvents lblq3 As Label
    Friend WithEvents txtq2 As TextBox
    Friend WithEvents txtq3 As TextBox
    Friend WithEvents txtq4 As TextBox
    Friend WithEvents lblq4 As Label
    Friend WithEvents lblq5 As Label
    Friend WithEvents txtq5 As TextBox
    Friend WithEvents lblq6 As Label
    Friend WithEvents lblq7 As Label
    Friend WithEvents lblq8 As Label
    Friend WithEvents txtq6 As TextBox
    Friend WithEvents txtq7 As TextBox
    Friend WithEvents txtq8 As TextBox
    Friend WithEvents lblq9 As Label
    Friend WithEvents lblq10 As Label
    Friend WithEvents txtq9 As TextBox
    Friend WithEvents txtq10 As TextBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnHome As Button
End Class
