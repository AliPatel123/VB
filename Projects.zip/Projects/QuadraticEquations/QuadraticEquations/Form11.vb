﻿Public Class Form11
    Dim ans1, ans2, ans3, ans4, ans5 As Decimal 'Declaring the answers as decimals

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Me.Close() 'Closing the form
    End Sub
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        ans1 = txtq1.Text 'Assigning the answer to the question as txtq1
        ans2 = txtq2.Text 'Assigning the answer to the question as txtq2
        ans3 = txtq3.Text 'Assigning the answer to the question as txtq3
        ans4 = txtq4.Text 'Assigning the answer to the question as txtq4
        ans5 = txtq5.Text 'Assigning the answer to the question as txtq5
        If ans1 = 9.23 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq1.Text = "Correct"
        Else
            txtq1.Text = "Incorrect"
        End If
        If ans2 = 2.79 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq2.Text = "Correct"
        Else
            txtq2.Text = "Incorrect"
        End If
        If ans3 = 13 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq3.Text = "Correct"
        Else
            txtq3.Text = "Incorrect"
        End If
        If ans4 = 40 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq4.Text = "Correct"
        Else
            txtq4.Text = "Incorrect"
        End If
        If ans5 = 46 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq5.Text = "Correct"
        Else
            txtq5.Text = "Incorrect"
        End If
    End Sub
End Class