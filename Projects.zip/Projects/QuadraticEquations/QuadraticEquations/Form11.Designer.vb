﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form11
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form11))
        Me.lblq1 = New System.Windows.Forms.Label()
        Me.lblq2 = New System.Windows.Forms.Label()
        Me.lblq3 = New System.Windows.Forms.Label()
        Me.lblq4 = New System.Windows.Forms.Label()
        Me.lblq5 = New System.Windows.Forms.Label()
        Me.txtq1 = New System.Windows.Forms.TextBox()
        Me.txtq3 = New System.Windows.Forms.TextBox()
        Me.txtq2 = New System.Windows.Forms.TextBox()
        Me.txtq4 = New System.Windows.Forms.TextBox()
        Me.txtq5 = New System.Windows.Forms.TextBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblq1
        '
        Me.lblq1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq1.Location = New System.Drawing.Point(7, 82)
        Me.lblq1.Name = "lblq1"
        Me.lblq1.Size = New System.Drawing.Size(1126, 76)
        Me.lblq1.TabIndex = 0
        Me.lblq1.Text = resources.GetString("lblq1.Text")
        '
        'lblq2
        '
        Me.lblq2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq2.Location = New System.Drawing.Point(7, 196)
        Me.lblq2.Name = "lblq2"
        Me.lblq2.Size = New System.Drawing.Size(1126, 65)
        Me.lblq2.TabIndex = 1
        Me.lblq2.Text = "2. With the same firework as question 1,  at what time will the firework initiall" &
    "y reach 100m above ground? Round to the nearest hundredth."
        '
        'lblq3
        '
        Me.lblq3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq3.Location = New System.Drawing.Point(7, 302)
        Me.lblq3.Name = "lblq3"
        Me.lblq3.Size = New System.Drawing.Size(1126, 72)
        Me.lblq3.TabIndex = 2
        Me.lblq3.Text = "3. The length of one leg of a right triangle is 7 cm more than another. The hypot" &
    "enuse's length is 3 cm more than double the original leg. What is the length of " &
    "the hypotenuse?"
        '
        'lblq4
        '
        Me.lblq4.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq4.Location = New System.Drawing.Point(7, 410)
        Me.lblq4.Name = "lblq4"
        Me.lblq4.Size = New System.Drawing.Size(1126, 64)
        Me.lblq4.TabIndex = 3
        Me.lblq4.Text = "4. A cylindrical can with a height of 12 cm has a capacity of 600 mL. What is the" &
    " radius to the nearest millimetre?"
        '
        'lblq5
        '
        Me.lblq5.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblq5.Location = New System.Drawing.Point(12, 512)
        Me.lblq5.Name = "lblq5"
        Me.lblq5.Size = New System.Drawing.Size(1121, 72)
        Me.lblq5.TabIndex = 4
        Me.lblq5.Text = "5. The area of a triangle is 20cm^2 and the altitude is 4 cm greater than the bas" &
    "e. Find the length of the base to the nearest millimetre."
        '
        'txtq1
        '
        Me.txtq1.Location = New System.Drawing.Point(539, 161)
        Me.txtq1.Name = "txtq1"
        Me.txtq1.Size = New System.Drawing.Size(100, 20)
        Me.txtq1.TabIndex = 10
        '
        'txtq3
        '
        Me.txtq3.Location = New System.Drawing.Point(539, 377)
        Me.txtq3.Name = "txtq3"
        Me.txtq3.Size = New System.Drawing.Size(100, 20)
        Me.txtq3.TabIndex = 11
        '
        'txtq2
        '
        Me.txtq2.Location = New System.Drawing.Point(539, 264)
        Me.txtq2.Name = "txtq2"
        Me.txtq2.Size = New System.Drawing.Size(100, 20)
        Me.txtq2.TabIndex = 12
        '
        'txtq4
        '
        Me.txtq4.Location = New System.Drawing.Point(539, 477)
        Me.txtq4.Name = "txtq4"
        Me.txtq4.Size = New System.Drawing.Size(100, 20)
        Me.txtq4.TabIndex = 13
        '
        'txtq5
        '
        Me.txtq5.Location = New System.Drawing.Point(539, 587)
        Me.txtq5.Name = "txtq5"
        Me.txtq5.Size = New System.Drawing.Size(100, 20)
        Me.txtq5.TabIndex = 14
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(451, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(272, 73)
        Me.lblTitle.TabIndex = 15
        Me.lblTitle.Text = "Practice"
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(549, 613)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 16
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(549, 642)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(75, 23)
        Me.btnHome.TabIndex = 17
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'Form11
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1164, 668)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.txtq5)
        Me.Controls.Add(Me.txtq4)
        Me.Controls.Add(Me.txtq2)
        Me.Controls.Add(Me.txtq3)
        Me.Controls.Add(Me.txtq1)
        Me.Controls.Add(Me.lblq5)
        Me.Controls.Add(Me.lblq4)
        Me.Controls.Add(Me.lblq3)
        Me.Controls.Add(Me.lblq2)
        Me.Controls.Add(Me.lblq1)
        Me.Name = "Form11"
        Me.Text = "Practice"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblq1 As Label
    Friend WithEvents lblq2 As Label
    Friend WithEvents lblq3 As Label
    Friend WithEvents lblq4 As Label
    Friend WithEvents lblq5 As Label
    Friend WithEvents txtq1 As TextBox
    Friend WithEvents txtq3 As TextBox
    Friend WithEvents txtq2 As TextBox
    Friend WithEvents txtq4 As TextBox
    Friend WithEvents txtq5 As TextBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnHome As Button
End Class
