﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form10
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form10))
        Me.picfactoring = New System.Windows.Forms.PictureBox()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.lblFactoring = New System.Windows.Forms.Label()
        Me.lblLesson = New System.Windows.Forms.Label()
        CType(Me.picfactoring, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picfactoring
        '
        Me.picfactoring.BackgroundImage = CType(resources.GetObject("picfactoring.BackgroundImage"), System.Drawing.Image)
        Me.picfactoring.Image = CType(resources.GetObject("picfactoring.Image"), System.Drawing.Image)
        Me.picfactoring.Location = New System.Drawing.Point(251, 162)
        Me.picfactoring.Name = "picfactoring"
        Me.picfactoring.Size = New System.Drawing.Size(477, 414)
        Me.picfactoring.TabIndex = 35
        Me.picfactoring.TabStop = False
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(936, 283)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(166, 49)
        Me.btnPrevious.TabIndex = 34
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(936, 401)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(166, 49)
        Me.btnHome.TabIndex = 33
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'lblFactoring
        '
        Me.lblFactoring.AutoSize = True
        Me.lblFactoring.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFactoring.Location = New System.Drawing.Point(95, 119)
        Me.lblFactoring.Name = "lblFactoring"
        Me.lblFactoring.Size = New System.Drawing.Size(111, 25)
        Me.lblFactoring.TabIndex = 31
        Me.lblFactoring.Text = "Factoring"
        '
        'lblLesson
        '
        Me.lblLesson.AutoSize = True
        Me.lblLesson.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLesson.Location = New System.Drawing.Point(473, 39)
        Me.lblLesson.Name = "lblLesson"
        Me.lblLesson.Size = New System.Drawing.Size(246, 73)
        Me.lblLesson.TabIndex = 30
        Me.lblLesson.Text = "Lesson"
        '
        'Form10
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1165, 645)
        Me.Controls.Add(Me.picfactoring)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.lblFactoring)
        Me.Controls.Add(Me.lblLesson)
        Me.Name = "Form10"
        Me.Text = "Lesson"
        CType(Me.picfactoring, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picfactoring As PictureBox
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents lblFactoring As Label
    Friend WithEvents lblLesson As Label
End Class
