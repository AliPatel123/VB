﻿Public Class Form3
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Me.Close() 'Closing the form

    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        Form2.Show() 'Showing the previous one then closing this one
        Me.Close()
    End Sub

    Private Sub btnNext1_Click(sender As Object, e As EventArgs) Handles btnNext1.Click
        Form5.Show() 'Showing the next form then closing this one
        Me.Close()
    End Sub
End Class