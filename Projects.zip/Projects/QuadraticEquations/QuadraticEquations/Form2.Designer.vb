﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.lblLesson = New System.Windows.Forms.Label()
        Me.lblSF = New System.Windows.Forms.Label()
        Me.picSF = New System.Windows.Forms.PictureBox()
        Me.btnNext1 = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        CType(Me.picSF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblLesson
        '
        Me.lblLesson.AutoSize = True
        Me.lblLesson.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLesson.Location = New System.Drawing.Point(456, 9)
        Me.lblLesson.Name = "lblLesson"
        Me.lblLesson.Size = New System.Drawing.Size(246, 73)
        Me.lblLesson.TabIndex = 0
        Me.lblLesson.Text = "Lesson"
        '
        'lblSF
        '
        Me.lblSF.AutoSize = True
        Me.lblSF.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSF.Location = New System.Drawing.Point(78, 109)
        Me.lblSF.Name = "lblSF"
        Me.lblSF.Size = New System.Drawing.Size(167, 25)
        Me.lblSF.TabIndex = 1
        Me.lblSF.Text = "Standard Form"
        '
        'picSF
        '
        Me.picSF.Image = CType(resources.GetObject("picSF.Image"), System.Drawing.Image)
        Me.picSF.Location = New System.Drawing.Point(12, 146)
        Me.picSF.Name = "picSF"
        Me.picSF.Size = New System.Drawing.Size(741, 487)
        Me.picSF.TabIndex = 2
        Me.picSF.TabStop = False
        '
        'btnNext1
        '
        Me.btnNext1.Location = New System.Drawing.Point(919, 253)
        Me.btnNext1.Name = "btnNext1"
        Me.btnNext1.Size = New System.Drawing.Size(166, 49)
        Me.btnNext1.TabIndex = 3
        Me.btnNext1.Text = "Next"
        Me.btnNext1.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(919, 371)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(166, 49)
        Me.btnHome.TabIndex = 4
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1165, 645)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnNext1)
        Me.Controls.Add(Me.picSF)
        Me.Controls.Add(Me.lblSF)
        Me.Controls.Add(Me.lblLesson)
        Me.Name = "Form2"
        Me.Text = "Lesson"
        CType(Me.picSF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblLesson As Label
    Friend WithEvents lblSF As Label
    Friend WithEvents picSF As PictureBox
    Friend WithEvents btnNext1 As Button
    Friend WithEvents btnHome As Button
End Class
