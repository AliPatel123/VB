﻿Public Class Form6
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Me.Close() 'Closing the form
    End Sub

    Private Sub btnNext1_Click(sender As Object, e As EventArgs) Handles btnNext1.Click
        Form7.Show() 'Showing the next form then closing this one
        Me.Close()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        Form4.Show() 'Showing the previous one Then closing this one
        Me.Close()
    End Sub
End Class