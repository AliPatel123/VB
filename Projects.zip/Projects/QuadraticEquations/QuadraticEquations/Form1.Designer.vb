﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnLesson = New System.Windows.Forms.Button()
        Me.btnPractice = New System.Windows.Forms.Button()
        Me.btnTest = New System.Windows.Forms.Button()
        Me.btnInstructions = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        resources.ApplyResources(Me.lblTitle, "lblTitle")
        Me.lblTitle.Name = "lblTitle"
        '
        'btnLesson
        '
        resources.ApplyResources(Me.btnLesson, "btnLesson")
        Me.btnLesson.Name = "btnLesson"
        Me.btnLesson.UseVisualStyleBackColor = True
        '
        'btnPractice
        '
        resources.ApplyResources(Me.btnPractice, "btnPractice")
        Me.btnPractice.Name = "btnPractice"
        Me.btnPractice.UseVisualStyleBackColor = True
        '
        'btnTest
        '
        resources.ApplyResources(Me.btnTest, "btnTest")
        Me.btnTest.Name = "btnTest"
        Me.btnTest.UseVisualStyleBackColor = True
        '
        'btnInstructions
        '
        resources.ApplyResources(Me.btnInstructions, "btnInstructions")
        Me.btnInstructions.Name = "btnInstructions"
        Me.btnInstructions.UseVisualStyleBackColor = True
        '
        'Form1
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.btnInstructions)
        Me.Controls.Add(Me.btnTest)
        Me.Controls.Add(Me.btnPractice)
        Me.Controls.Add(Me.btnLesson)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents btnLesson As Button
    Friend WithEvents btnPractice As Button
    Friend WithEvents btnTest As Button
    Friend WithEvents btnInstructions As Button
End Class
