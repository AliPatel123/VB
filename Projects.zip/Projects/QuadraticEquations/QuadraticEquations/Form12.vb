﻿Public Class Form12
    Dim ans1, ans2, ans3, ans4, ans5, ans6, ans7, ans8, ans9, ans10 As Decimal 'Declaring the answers as a decimal
    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        Me.Close() 'Closing the form
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        ans1 = txtq1.Text 'Assigning the answer's value to the respective text box
        ans2 = txtq2.Text 'Assigning the answer's value to the respective text box
        ans3 = txtq3.Text 'Assigning the answer's value to the respective text box
        ans4 = txtq4.Text 'Assigning the answer's value to the respective text box
        ans5 = txtq5.Text 'Assigning the answer's value to the respective text box
        ans6 = txtq6.Text 'Assigning the answer's value to the respective text box
        ans7 = txtq7.Text 'Assigning the answer's value to the respective text box
        ans8 = txtq8.Text 'Assigning the answer's value to the respective text box
        ans9 = txtq9.Text 'Assigning the answer's value to the respective text box
        ans10 = txtq10.Text 'Assigning the answer's value to the respective text box
        If ans1 = 0.8 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq1.Text = "Correct"
        Else
            txtq1.Text = "Incorrect"
        End If
        If ans2 = 8 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq2.Text = "Correct"
        Else
            txtq2.Text = "Incorrect"
        End If
        If ans3 = 1.25 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq3.Text = "Correct"
        Else
            txtq3.Text = "Incorrect"
        End If
        If ans4 = 3.2 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq4.Text = "Correct"
        Else
            txtq4.Text = "Incorrect"
        End If
        If ans5 = 60 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq5.Text = "Correct"
        Else
            txtq5.Text = "Incorrect"
        End If
        If ans6 = 2 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq6.Text = "Correct"
        Else
            txtq6.Text = "Incorrect"
        End If
        If ans7 = 3 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq7.Text = "Correct"
        Else
            txtq7.Text = "Incorrect"
        End If
        If ans8 = 4 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq8.Text = "Correct"
        Else
            txtq8.Text = "Incorrect"
        End If
        If ans9 = 12 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq9.Text = "Correct"
        Else
            txtq9.Text = "Incorrect"
        End If
        If ans10 = 60 Then 'Displaying correct or incorrect based on if the answer is correct or incorrect
            txtq10.Text = "Correct"
        Else
            txtq10.Text = "Incorrect"
        End If
    End Sub
End Class