﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form9
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form9))
        Me.picFactoring = New System.Windows.Forms.PictureBox()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.btnNext1 = New System.Windows.Forms.Button()
        Me.lblfactoring = New System.Windows.Forms.Label()
        Me.lblLesson = New System.Windows.Forms.Label()
        CType(Me.picFactoring, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picFactoring
        '
        Me.picFactoring.BackgroundImage = CType(resources.GetObject("picFactoring.BackgroundImage"), System.Drawing.Image)
        Me.picFactoring.Image = CType(resources.GetObject("picFactoring.Image"), System.Drawing.Image)
        Me.picFactoring.Location = New System.Drawing.Point(247, 144)
        Me.picFactoring.Name = "picFactoring"
        Me.picFactoring.Size = New System.Drawing.Size(669, 691)
        Me.picFactoring.TabIndex = 35
        Me.picFactoring.TabStop = False
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(936, 346)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(166, 49)
        Me.btnPrevious.TabIndex = 34
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = True
        '
        'btnHome
        '
        Me.btnHome.Location = New System.Drawing.Point(936, 401)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(166, 49)
        Me.btnHome.TabIndex = 33
        Me.btnHome.Text = "Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'btnNext1
        '
        Me.btnNext1.Location = New System.Drawing.Point(936, 291)
        Me.btnNext1.Name = "btnNext1"
        Me.btnNext1.Size = New System.Drawing.Size(166, 49)
        Me.btnNext1.TabIndex = 32
        Me.btnNext1.Text = "Next"
        Me.btnNext1.UseVisualStyleBackColor = True
        '
        'lblfactoring
        '
        Me.lblfactoring.AutoSize = True
        Me.lblfactoring.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfactoring.Location = New System.Drawing.Point(95, 119)
        Me.lblfactoring.Name = "lblfactoring"
        Me.lblfactoring.Size = New System.Drawing.Size(111, 25)
        Me.lblfactoring.TabIndex = 31
        Me.lblfactoring.Text = "Factoring"
        '
        'lblLesson
        '
        Me.lblLesson.AutoSize = True
        Me.lblLesson.Font = New System.Drawing.Font("Microsoft Sans Serif", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLesson.Location = New System.Drawing.Point(473, 39)
        Me.lblLesson.Name = "lblLesson"
        Me.lblLesson.Size = New System.Drawing.Size(246, 73)
        Me.lblLesson.TabIndex = 30
        Me.lblLesson.Text = "Lesson"
        '
        'Form9
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(1165, 886)
        Me.Controls.Add(Me.picFactoring)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnNext1)
        Me.Controls.Add(Me.lblfactoring)
        Me.Controls.Add(Me.lblLesson)
        Me.Name = "Form9"
        Me.Text = "Lesson"
        CType(Me.picFactoring, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picFactoring As PictureBox
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnHome As Button
    Friend WithEvents btnNext1 As Button
    Friend WithEvents lblfactoring As Label
    Friend WithEvents lblLesson As Label
End Class
