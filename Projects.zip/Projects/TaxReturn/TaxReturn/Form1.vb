﻿Public Class FederalTaxReturn2016


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dblIncome As Double 'Annual Income
        dblIncome = txtIncome.Text
        Dim dblTax As Double = 0
        'Decision based on the income
        If dblIncome <= 45282 Then
            dblTax = dblIncome * 0.15
        ElseIf dblIncome > 45282 And dblIncome <= 90563 Then
            dblTax = 45282 * 0.15 + (dblIncome - 45282) * 0.205
        ElseIf dblIncome > 90563 And dblIncome <= 140388 Then
            dblTax = 45282 * 0.15 + (90563 - 45282) * 0.205 +
                (140388 - 90563) * 0.26
        End If
        txtTax.Text = dblTax

    End Sub
End Class
