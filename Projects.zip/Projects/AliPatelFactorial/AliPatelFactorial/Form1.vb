﻿Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intnumber As Integer = txtNumber.Text 'Declaring the input and assigning it to the initial user input
        Dim Factorial As Integer = 1 'Declaring the factorial variable and assigning it a value of 1
        Dim Count As Integer 'Adding a counter
        For Count = intnumber To 1 Step -1 'Doing the for statement for the count
            Factorial = Factorial * Count 'Multiplying the factorial by the number under ot
        Next
        lblDisplay.Text = Factorial 'Displaying the factorial
    End Sub
End Class
