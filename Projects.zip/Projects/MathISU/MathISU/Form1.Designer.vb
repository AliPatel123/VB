﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnSimTri = New System.Windows.Forms.Button()
        Me.btnSineLaw = New System.Windows.Forms.Button()
        Me.btnQuad = New System.Windows.Forms.Button()
        Me.btnVertexForm = New System.Windows.Forms.Button()
        Me.btnUser = New System.Windows.Forms.Button()
        Me.btnTrig = New System.Windows.Forms.Button()
        Me.btnCosLaw = New System.Windows.Forms.Button()
        Me.btnQuadFormula = New System.Windows.Forms.Button()
        Me.btnxint = New System.Windows.Forms.Button()
        Me.btnOL = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(212, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Math Exam Review"
        '
        'btnSimTri
        '
        Me.btnSimTri.Location = New System.Drawing.Point(8, 53)
        Me.btnSimTri.Name = "btnSimTri"
        Me.btnSimTri.Size = New System.Drawing.Size(129, 23)
        Me.btnSimTri.TabIndex = 1
        Me.btnSimTri.Text = "Similar Triangles"
        Me.btnSimTri.UseVisualStyleBackColor = True
        '
        'btnSineLaw
        '
        Me.btnSineLaw.Location = New System.Drawing.Point(8, 82)
        Me.btnSineLaw.Name = "btnSineLaw"
        Me.btnSineLaw.Size = New System.Drawing.Size(129, 23)
        Me.btnSineLaw.TabIndex = 2
        Me.btnSineLaw.Text = "Sine Law"
        Me.btnSineLaw.UseVisualStyleBackColor = True
        '
        'btnQuad
        '
        Me.btnQuad.Location = New System.Drawing.Point(8, 111)
        Me.btnQuad.Name = "btnQuad"
        Me.btnQuad.Size = New System.Drawing.Size(129, 23)
        Me.btnQuad.TabIndex = 3
        Me.btnQuad.Text = "Quadratic Equations"
        Me.btnQuad.UseVisualStyleBackColor = True
        '
        'btnVertexForm
        '
        Me.btnVertexForm.Location = New System.Drawing.Point(8, 141)
        Me.btnVertexForm.Name = "btnVertexForm"
        Me.btnVertexForm.Size = New System.Drawing.Size(129, 23)
        Me.btnVertexForm.TabIndex = 4
        Me.btnVertexForm.Text = "Vertex Form"
        Me.btnVertexForm.UseVisualStyleBackColor = True
        '
        'btnUser
        '
        Me.btnUser.Location = New System.Drawing.Point(143, 170)
        Me.btnUser.Name = "btnUser"
        Me.btnUser.Size = New System.Drawing.Size(129, 23)
        Me.btnUser.TabIndex = 5
        Me.btnUser.Text = "User Manual"
        Me.btnUser.UseVisualStyleBackColor = True
        '
        'btnTrig
        '
        Me.btnTrig.Location = New System.Drawing.Point(143, 53)
        Me.btnTrig.Name = "btnTrig"
        Me.btnTrig.Size = New System.Drawing.Size(129, 23)
        Me.btnTrig.TabIndex = 6
        Me.btnTrig.Text = "Trigonometry"
        Me.btnTrig.UseVisualStyleBackColor = True
        '
        'btnCosLaw
        '
        Me.btnCosLaw.Location = New System.Drawing.Point(143, 82)
        Me.btnCosLaw.Name = "btnCosLaw"
        Me.btnCosLaw.Size = New System.Drawing.Size(129, 23)
        Me.btnCosLaw.TabIndex = 7
        Me.btnCosLaw.Text = "Cosine Law"
        Me.btnCosLaw.UseVisualStyleBackColor = True
        '
        'btnQuadFormula
        '
        Me.btnQuadFormula.Location = New System.Drawing.Point(143, 111)
        Me.btnQuadFormula.Name = "btnQuadFormula"
        Me.btnQuadFormula.Size = New System.Drawing.Size(129, 23)
        Me.btnQuadFormula.TabIndex = 8
        Me.btnQuadFormula.Text = "Quadratic Formula"
        Me.btnQuadFormula.UseVisualStyleBackColor = True
        '
        'btnxint
        '
        Me.btnxint.Location = New System.Drawing.Point(143, 141)
        Me.btnxint.Name = "btnxint"
        Me.btnxint.Size = New System.Drawing.Size(129, 23)
        Me.btnxint.TabIndex = 9
        Me.btnxint.Text = "X-Intercept Form"
        Me.btnxint.UseVisualStyleBackColor = True
        '
        'btnOL
        '
        Me.btnOL.Location = New System.Drawing.Point(8, 170)
        Me.btnOL.Name = "btnOL"
        Me.btnOL.Size = New System.Drawing.Size(129, 23)
        Me.btnOL.TabIndex = 10
        Me.btnOL.Text = "Final Test"
        Me.btnOL.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 208)
        Me.Controls.Add(Me.btnOL)
        Me.Controls.Add(Me.btnxint)
        Me.Controls.Add(Me.btnQuadFormula)
        Me.Controls.Add(Me.btnCosLaw)
        Me.Controls.Add(Me.btnTrig)
        Me.Controls.Add(Me.btnUser)
        Me.Controls.Add(Me.btnVertexForm)
        Me.Controls.Add(Me.btnQuad)
        Me.Controls.Add(Me.btnSineLaw)
        Me.Controls.Add(Me.btnSimTri)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Math Exam Review"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnSimTri As Button
    Friend WithEvents btnSineLaw As Button
    Friend WithEvents btnQuad As Button
    Friend WithEvents btnVertexForm As Button
    Friend WithEvents btnUser As Button
    Friend WithEvents btnTrig As Button
    Friend WithEvents btnCosLaw As Button
    Friend WithEvents btnQuadFormula As Button
    Friend WithEvents btnxint As Button
    Friend WithEvents btnOL As Button
End Class
