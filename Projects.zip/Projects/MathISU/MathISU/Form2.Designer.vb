﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.lblSimTriTitle = New System.Windows.Forms.Label()
        Me.lblSimTriLesson = New System.Windows.Forms.Label()
        Me.lblSimTriLesson2 = New System.Windows.Forms.Label()
        Me.picSimTri = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        CType(Me.picSimTri, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblSimTriTitle
        '
        Me.lblSimTriTitle.AutoSize = True
        Me.lblSimTriTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSimTriTitle.Location = New System.Drawing.Point(216, 9)
        Me.lblSimTriTitle.Name = "lblSimTriTitle"
        Me.lblSimTriTitle.Size = New System.Drawing.Size(235, 33)
        Me.lblSimTriTitle.TabIndex = 0
        Me.lblSimTriTitle.Text = "Similar Triangles"
        '
        'lblSimTriLesson
        '
        Me.lblSimTriLesson.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSimTriLesson.Location = New System.Drawing.Point(8, 42)
        Me.lblSimTriLesson.Name = "lblSimTriLesson"
        Me.lblSimTriLesson.Size = New System.Drawing.Size(321, 122)
        Me.lblSimTriLesson.TabIndex = 1
        Me.lblSimTriLesson.Text = "Two triangles are Similar if the only difference is size (and possibly the need t" &
    "o turn or flip one around). Examples are shown below. Equal angles have been mar" &
    "ked with the same number of arcs."
        '
        'lblSimTriLesson2
        '
        Me.lblSimTriLesson2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSimTriLesson2.Location = New System.Drawing.Point(351, 42)
        Me.lblSimTriLesson2.Name = "lblSimTriLesson2"
        Me.lblSimTriLesson2.Size = New System.Drawing.Size(309, 101)
        Me.lblSimTriLesson2.TabIndex = 2
        Me.lblSimTriLesson2.Text = "Similar triangles have:                                     All their angles equa" &
    "l.                            Corresponding sides with the same ratio."
        '
        'picSimTri
        '
        Me.picSimTri.Image = CType(resources.GetObject("picSimTri.Image"), System.Drawing.Image)
        Me.picSimTri.Location = New System.Drawing.Point(12, 175)
        Me.picSimTri.Name = "picSimTri"
        Me.picSimTri.Size = New System.Drawing.Size(464, 204)
        Me.picSimTri.TabIndex = 3
        Me.picSimTri.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(536, 222)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(536, 302)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(672, 391)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.picSimTri)
        Me.Controls.Add(Me.lblSimTriLesson2)
        Me.Controls.Add(Me.lblSimTriLesson)
        Me.Controls.Add(Me.lblSimTriTitle)
        Me.Name = "Form2"
        Me.Text = "Similar Triangles"
        CType(Me.picSimTri, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblSimTriTitle As Label
    Friend WithEvents lblSimTriLesson As Label
    Friend WithEvents lblSimTriLesson2 As Label
    Friend WithEvents picSimTri As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
