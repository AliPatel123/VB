﻿Public Class Form1
    Private Sub btnSimTri_Click(sender As Object, e As EventArgs) Handles btnSimTri.Click
        Form2.Show()
    End Sub
End Class
