﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblFuture = New System.Windows.Forms.Label()
        Me.lblInterest = New System.Windows.Forms.Label()
        Me.lblYears = New System.Windows.Forms.Label()
        Me.txtFutureValue = New System.Windows.Forms.TextBox()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.nudYears = New System.Windows.Forms.NumericUpDown()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lstInvestments = New System.Windows.Forms.ListBox()
        CType(Me.nudYears, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblFuture
        '
        Me.lblFuture.AutoSize = True
        Me.lblFuture.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFuture.Location = New System.Drawing.Point(12, 59)
        Me.lblFuture.Name = "lblFuture"
        Me.lblFuture.Size = New System.Drawing.Size(154, 25)
        Me.lblFuture.TabIndex = 0
        Me.lblFuture.Text = "Future Value:"
        '
        'lblInterest
        '
        Me.lblInterest.AutoSize = True
        Me.lblInterest.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInterest.Location = New System.Drawing.Point(12, 95)
        Me.lblInterest.Name = "lblInterest"
        Me.lblInterest.Size = New System.Drawing.Size(154, 25)
        Me.lblInterest.TabIndex = 1
        Me.lblInterest.Text = "Interest Rate:"
        '
        'lblYears
        '
        Me.lblYears.AutoSize = True
        Me.lblYears.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblYears.Location = New System.Drawing.Point(12, 132)
        Me.lblYears.Name = "lblYears"
        Me.lblYears.Size = New System.Drawing.Size(81, 25)
        Me.lblYears.TabIndex = 2
        Me.lblYears.Text = "Years:"
        '
        'txtFutureValue
        '
        Me.txtFutureValue.Location = New System.Drawing.Point(172, 65)
        Me.txtFutureValue.Name = "txtFutureValue"
        Me.txtFutureValue.Size = New System.Drawing.Size(100, 20)
        Me.txtFutureValue.TabIndex = 3
        '
        'txtRate
        '
        Me.txtRate.Location = New System.Drawing.Point(172, 100)
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(100, 20)
        Me.txtRate.TabIndex = 4
        '
        'nudYears
        '
        Me.nudYears.Increment = New Decimal(New Integer() {5, 0, 0, 0})
        Me.nudYears.Location = New System.Drawing.Point(99, 139)
        Me.nudYears.Name = "nudYears"
        Me.nudYears.Size = New System.Drawing.Size(173, 20)
        Me.nudYears.TabIndex = 5
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(99, 174)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 26)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lstInvestments
        '
        Me.lstInvestments.FormattingEnabled = True
        Me.lstInvestments.Location = New System.Drawing.Point(12, 206)
        Me.lstInvestments.Name = "lstInvestments"
        Me.lstInvestments.Size = New System.Drawing.Size(260, 147)
        Me.lstInvestments.TabIndex = 7
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 368)
        Me.Controls.Add(Me.lstInvestments)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.nudYears)
        Me.Controls.Add(Me.txtRate)
        Me.Controls.Add(Me.txtFutureValue)
        Me.Controls.Add(Me.lblYears)
        Me.Controls.Add(Me.lblInterest)
        Me.Controls.Add(Me.lblFuture)
        Me.Name = "Form1"
        Me.Text = "Present Value Calculator"
        CType(Me.nudYears, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblFuture As Label
    Friend WithEvents lblInterest As Label
    Friend WithEvents lblYears As Label
    Friend WithEvents txtFutureValue As TextBox
    Friend WithEvents txtRate As TextBox
    Friend WithEvents nudYears As NumericUpDown
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lstInvestments As ListBox
End Class
