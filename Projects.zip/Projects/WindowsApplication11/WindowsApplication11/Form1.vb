﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim FVal As Double = txtFutureValue.Text 'Declaring future value variable and assigning it appropriately
        Dim Rate As Double = txtRate.Text
        Dim Years As Integer = nudYears.Value
        Dim Count As Integer
        For Count = 0 To Years Step 5 'Calculating Investments
            If Count = 0 Then
                lstInvestments.Items.Add("Years             Required") 'Displaying Header
            Else
                Dim Display As Double
                Display = FVal / (1 + (Rate / 100)) ^ Count 'Displaying the Answers
                lstInvestments.Items.Add(Count & "                    " & FormatNumber((Display), 2))
            End If
        Next

    End Sub
End Class
