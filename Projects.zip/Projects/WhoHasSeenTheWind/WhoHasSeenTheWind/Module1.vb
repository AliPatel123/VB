﻿Module Module1

    Sub Main()
        Dim Humidity As Integer = Console.ReadLine 'Declaring the humidity as an integer variable
        Dim WaitTime As Integer = Console.ReadLine 'Declaring the Time that she will wait as an integer variable
        Dim Alt As Integer 'Declaring the altitude as a double
        Dim Time As Integer = 1 'Declaring the time as a double
        Do Until Alt = 0
            For Time = 1 To WaitTime
                Alt = (-6 * (Time ^ 4)) + (Humidity * (Time ^ 3)) + (2 * (Time ^ 2)) + Time
                Time += 1
            Next
        Loop
        If Alt = 0 And Time <= WaitTime Then
            Console.WriteLine("The ballon first touches ground at hour: " & Time)
        Else
            Console.WriteLine("The balloon does not touch ground in the given time.")
        End If
        Console.ReadLine()
    End Sub

End Module
