﻿Module Module1

    Sub Main()
        Dim strWord As String
        strWord = Console.ReadLine
        strWord = strWord.ToUpper()
        Dim strinv As String = ""
        For i = strWord.Length - 1 To 0 Step -1
            strinv += strWord(i)
        Next
        If strWord = strinv Then
            Console.WriteLine("Palindrome")
        Else
            Console.WriteLine("Not a Palindrome")
        End If
        Console.ReadLine()
    End Sub

End Module
