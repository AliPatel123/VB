﻿Public Class Form1
    Private Sub chkEnglish_CheckedChanged(sender As Object, e As EventArgs) Handles chkEnglish.CheckedChanged
        If chkEnglish.Checked Then
            lblDisplay.Text = "Welcome"
            chkFrench.

        End If
    End Sub
End Class
