﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDisplay = New System.Windows.Forms.Label()
        Me.chkEnglish = New System.Windows.Forms.CheckBox()
        Me.chkLatin = New System.Windows.Forms.CheckBox()
        Me.chkFrench = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'lblDisplay
        '
        Me.lblDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDisplay.Location = New System.Drawing.Point(12, 296)
        Me.lblDisplay.Name = "lblDisplay"
        Me.lblDisplay.Size = New System.Drawing.Size(622, 246)
        Me.lblDisplay.TabIndex = 0
        '
        'chkEnglish
        '
        Me.chkEnglish.AutoSize = True
        Me.chkEnglish.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkEnglish.Location = New System.Drawing.Point(48, 182)
        Me.chkEnglish.Name = "chkEnglish"
        Me.chkEnglish.Size = New System.Drawing.Size(109, 29)
        Me.chkEnglish.TabIndex = 1
        Me.chkEnglish.Text = "English"
        Me.chkEnglish.UseVisualStyleBackColor = True
        '
        'chkLatin
        '
        Me.chkLatin.AutoSize = True
        Me.chkLatin.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkLatin.Location = New System.Drawing.Point(461, 182)
        Me.chkLatin.Name = "chkLatin"
        Me.chkLatin.Size = New System.Drawing.Size(83, 29)
        Me.chkLatin.TabIndex = 2
        Me.chkLatin.Text = "Latin"
        Me.chkLatin.UseVisualStyleBackColor = True
        '
        'chkFrench
        '
        Me.chkFrench.AutoSize = True
        Me.chkFrench.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkFrench.Location = New System.Drawing.Point(260, 182)
        Me.chkFrench.Name = "chkFrench"
        Me.chkFrench.Size = New System.Drawing.Size(104, 29)
        Me.chkFrench.TabIndex = 3
        Me.chkFrench.Text = "French"
        Me.chkFrench.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(646, 551)
        Me.Controls.Add(Me.chkFrench)
        Me.Controls.Add(Me.chkLatin)
        Me.Controls.Add(Me.chkEnglish)
        Me.Controls.Add(Me.lblDisplay)
        Me.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.Name = "Form1"
        Me.Text = "Welcome Multi Language"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDisplay As Label
    Friend WithEvents chkEnglish As CheckBox
    Friend WithEvents chkLatin As CheckBox
    Friend WithEvents chkFrench As CheckBox
End Class
