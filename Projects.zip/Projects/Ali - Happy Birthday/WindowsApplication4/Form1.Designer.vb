﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHappyBirthday = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblBirthday = New System.Windows.Forms.Label()
        Me.rdbEnter = New System.Windows.Forms.Button()
        Me.txtBirthday = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblOutput = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblHappyBirthday
        '
        Me.lblHappyBirthday.AutoSize = True
        Me.lblHappyBirthday.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHappyBirthday.Location = New System.Drawing.Point(190, 29)
        Me.lblHappyBirthday.Name = "lblHappyBirthday"
        Me.lblHappyBirthday.Size = New System.Drawing.Size(173, 25)
        Me.lblHappyBirthday.TabIndex = 0
        Me.lblHappyBirthday.Text = "Happy Birthday"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.Location = New System.Drawing.Point(12, 86)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(177, 24)
        Me.lblName.TabIndex = 1
        Me.lblName.Text = "Enter Your Name:"
        '
        'lblBirthday
        '
        Me.lblBirthday.AutoSize = True
        Me.lblBirthday.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthday.Location = New System.Drawing.Point(12, 177)
        Me.lblBirthday.Name = "lblBirthday"
        Me.lblBirthday.Size = New System.Drawing.Size(197, 24)
        Me.lblBirthday.TabIndex = 2
        Me.lblBirthday.Text = "Enter Your Birthday:"
        '
        'rdbEnter
        '
        Me.rdbEnter.Location = New System.Drawing.Point(195, 272)
        Me.rdbEnter.Name = "rdbEnter"
        Me.rdbEnter.Size = New System.Drawing.Size(180, 63)
        Me.rdbEnter.TabIndex = 3
        Me.rdbEnter.Text = "Enter"
        Me.rdbEnter.UseVisualStyleBackColor = True
        '
        'txtBirthday
        '
        Me.txtBirthday.Location = New System.Drawing.Point(353, 182)
        Me.txtBirthday.Name = "txtBirthday"
        Me.txtBirthday.Size = New System.Drawing.Size(100, 20)
        Me.txtBirthday.TabIndex = 4
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(353, 90)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 5
        '
        'lblOutput
        '
        Me.lblOutput.AutoSize = True
        Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutput.Location = New System.Drawing.Point(167, 390)
        Me.lblOutput.Name = "lblOutput"
        Me.lblOutput.Size = New System.Drawing.Size(83, 25)
        Me.lblOutput.TabIndex = 6
        Me.lblOutput.Text = "Label1"
        Me.lblOutput.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(585, 495)
        Me.Controls.Add(Me.lblOutput)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.txtBirthday)
        Me.Controls.Add(Me.rdbEnter)
        Me.Controls.Add(Me.lblBirthday)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.lblHappyBirthday)
        Me.Name = "Form1"
        Me.Text = "Happy Birthday"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHappyBirthday As Label
    Friend WithEvents lblName As Label
    Friend WithEvents lblBirthday As Label
    Friend WithEvents rdbEnter As Button
    Friend WithEvents txtBirthday As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblOutput As Label
End Class
