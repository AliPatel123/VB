﻿Public Class Form1
    Private Sub rdbEnter_Click(sender As Object, e As EventArgs) Handles rdbEnter.Click
        lblOutput.Visible = True
        Dim Name As String
        Dim Birthday As String
        Name = txtName.Text
        Birthday = txtBirthday.Text
        lblOutput.Text = Name & "'s birthday is on " & Birthday
    End Sub
End Class
