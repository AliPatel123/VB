﻿Module Module1

    Sub Main()
        Dim intNumber As Integer
        intNumber = Console.ReadLine
        Do
            'Here the condition is checked at the end
            Console.WriteLine(intNumber)
            Console.WriteLine("Enter a Number")
            intNumber = Console.ReadLine
        Loop While (intNumber Mod 2 = 0)
        Console.WriteLine("The Do Until Loop End Here")
        Console.ReadLine()
    End Sub

End Module
