﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim Grade As Integer
        Grade = txtMarks.Text
        If Grade >= 90 Or Grade <= 100 Then
            txtGrade.Text = "A"
        ElseIf Grade >= 80 And Grade < 90 Then
            txtGrade.Text = "A-"
        ElseIf Grade >= 75 And Grade < 80 Then
            txtGrade.Text = "B+"
        Else
            txtGrade.Text = "F"
        End If
    End Sub
End Class
