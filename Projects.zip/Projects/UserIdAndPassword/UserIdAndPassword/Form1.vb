﻿Public Class Form1
    Dim intcount As Integer = 0
    Private Sub lblUserID_Click(sender As Object, e As EventArgs) Handles lblUserID.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Your password and userid
        Dim strUserID As String = "donald"
        Dim intPassword As Integer = 12345
        Dim strID As String = txtuserID.Text
        Dim intPwd As Integer = Val(txtPassword.Text)
        'the Val will change the Text into an Integer Value

        If strID = strUserID And intPwd = intPassword Then
            MsgBox("Welcome To White House")
            txtPassword.Clear()
            txtuserID.Clear()

        ElseIf strID <> strUserID And intPwd = intPassword Then
            MsgBox("User ID is not correct")
            txtPassword.Clear()
            txtuserID.Clear()
            ' <> for Not
            intcount = intcount + 1
        ElseIf strID = strUserID And intPwd <> intPassword Then
            MsgBox("Password  is not correct")
            txtPassword.Clear()
            txtuserID.Clear()
            intcount = intcount + 1
        ElseIf strID <> strUserID Or intPwd <> intPassword Then
            MsgBox("The User ID or the Password is not correct")
            txtPassword.Clear()
            txtuserID.Clear()
            intcount = intcount + 1
        End If

        If intcount = 3 Then
            MsgBox()

        End If


    End Sub
End Class
