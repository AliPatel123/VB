﻿Public Class Form1
    Private Sub btnNewProblem_Click(sender As Object, e As EventArgs) Handles btnNewProblem.Click
        Dim intNumber1 As Integer = Rnd() * 10 'Declaring integers and assigning them a random value
        Dim intNumber2 As Integer = Rnd() * 10
        Dim strOperation As Integer = Rnd() * 4
        Select Case (strOperation) 'Displaying an operator instead of a number
            Case 1 : lblOperator.Text = "+"
            Case 2 : lblOperator.Text = "-"
            Case 3 : lblOperator.Text = "*"
            Case 4 : lblOperator.Text = "\"
        End Select
        lblNum1.Text = intNumber1 'Assigning the integers to the labels
        lblNum2.Text = intNumber2
        lblEqualSign.Visible = True 'Enabling visibility of the equal sign
    End Sub
    Private Sub btnShowAnswer_Click(sender As Object, e As EventArgs) Handles btnShowAnswer.Click
        If lblOperator.Text = "+" Then
            txtAnswer.Text = Val(lblNum1.Text) + Val(lblNum2.Text) 'Doing the addition (must use val (value) or else it will put the 2 numbers together such as 10 + 9 = 109
        End If
        If lblOperator.Text = "-" Then
            txtAnswer.Text = (lblNum1.Text) - (lblNum2.Text) 'Doing the subtraction
        End If
        If lblOperator.Text = "*" Then
            txtAnswer.Text = (lblNum1.Text) * (lblNum2.Text) 'Doing multiplication
        End If
        If lblOperator.Text = "\" Then
            txtAnswer.Text = (lblNum1.Text) \ (lblNum2.Text) 'Doing the division
        End If
    End Sub
    Private Sub btnCheckAnswer_Click(sender As Object, e As EventArgs) Handles btnCheckAnswer.Click
        Dim intTemporary As Integer
        If lblOperator.Text = "+" Then
            intTemporary = Val(lblNum1.Text) + Val(lblNum2.Text) 'Doing the addition without displaying it
        ElseIf lblOperator.Text = "-" Then
            intTemporary = (lblNum1.Text) - (lblNum2.Text) 'Doing the subtraction without displaying it
        ElseIf lblOperator.Text = "*" Then
            intTemporary = (lblNum1.Text) * (lblNum2.Text) 'Doing the multiplication without displaying it
        ElseIf lblOperator.Text = "\" Then
            intTemporary = (lblNum1.Text) \ (lblNum2.Text) 'Doing the division without displaying it
        End If
        If txtAnswer.Text = intTemporary Then 'Checking to see if the answer is right
            lblDisplay.Text = " Correct Answer!" 'Telling the person if they are right
        ElseIf txtAnswer.Text <> intTemporary Then
            lblDisplay.Text = "Incorrect Answer!" 'Telling them they are wrong
        End If
    End Sub
End Class