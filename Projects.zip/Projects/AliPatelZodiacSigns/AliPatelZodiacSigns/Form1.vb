﻿Public Class Form1
    Dim Month As Integer 'Declaring the months as an integer
    Dim Days As Integer 'Declaring the days as an integer
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Month = txtMonth.Text 'Assigning the value of "Month" to the user's input in text box "txtMonth"
        Days = txtDay.Text 'Assigning the value of "Days" to the user's input in text box "txtDay"

        If Month = 12 And Days >= 22 Or Month = 1 And Days <= 19 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Capricorn
            txtDisplay.Text = "Capricorn" 'Displays "Capricorn" if the user's birthday falls within the timeframe of the zodiac sign Capricorn 
        ElseIf Month = 1 And Days >= 20 Or Month = 2 And Days <= 17 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Aquarius
            txtDisplay.Text = "Aquarius" 'Displays "Aquarius" if the user's birthday falls within the timeframe of the zodiac sign Aquarius
        ElseIf Month = 2 And Days >= 18 Or Month = 3 And Days <= 19 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Pisces
            txtDisplay.Text = "Pisces" 'Displays "Pisces" if the user's birthday falls within the timeframe of the zodiac sign Pisces
        ElseIf Month = 3 And Days >= 20 Or Month = 4 And Days <= 19 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Aries
            txtDisplay.Text = "Aries" 'Displays "Aries" if the user's birthday falls within the timeframe of the zodiac sign Aries
        ElseIf Month = 4 And Days >= 20 Or Month = 5 And Days <= 20 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Taurus
            txtDisplay.Text = "Taurus" 'Displays "Taurus" if the user's birthday falls within the timeframe of the zodiac sign Taurus
        ElseIf Month = 5 And Days >= 21 Or Month = 6 And Days <= 20 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Gemini
            txtDisplay.Text = "Gemini" 'Displays "Gemini" if the user's birthday falls within the timeframe of the zodiac sign Gemini
        ElseIf Month = 6 And Days >= 21 Or Month = 7 And Days <= 22 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Cancer
            txtDisplay.Text = "Cancer" 'Displays "Cancer" if the user's birthday falls within the timeframe of the zodiac sign Cancer
        ElseIf Month = 7 And Days >= 23 Or Month = 8 And Days <= 22 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Leo
            txtDisplay.Text = "Leo" 'Displays "Leo" if the user's birthday falls within the timeframe of the zodiac sign Leo
        ElseIf Month = 8 And Days >= 23 Or Month = 9 And Days <= 22 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Virgo
            txtDisplay.Text = "Virgo" 'Displays "Virgo" if the user's birthday falls within the timeframe of the zodiac sign Virgo
        ElseIf Month = 9 And Days >= 23 Or Month = 10 And Days <= 22 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Libra
            txtDisplay.Text = "Libra" 'Displays "Libra" if the user's birthday falls within the timeframe of the zodiac sign Libra
        ElseIf Month = 10 And Days >= 23 Or Month = 11 And Days <= 21 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Scorpio
            txtDisplay.Text = "Scorpio" 'Displays "Scorpio" if the user's birthday falls within the timeframe of the zodiac sign Scorpio
        ElseIf Month = 11 And Days >= 22 Or Month = 12 And Days <= 21 Then 'Checking if the user's birthday falls within the range of dates that are symbolized by the zodiac sign Saggitarius
            txtDisplay.Text = "Saggitarius" 'Displays "Saggitarius" if the user's birthday falls within the timeframe of the zodiac sign Saggitarius
        End If
    End Sub
End Class
