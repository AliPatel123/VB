﻿Module Module1
    Sub Main()
        For i = 1 To 1729
            For j = 1 To 1729
                For k = 1 To 1729
                    If (i ^ 3) + (j ^ 3) = k Then
                        Console.WriteLine(i & vbTab & j & vbTab & k)
                    End If
                Next
            Next
        Next
        Console.ReadLine()
    End Sub
End Module
